import { z } from "zod";
import { eq, sql, count, desc } from "drizzle-orm";
import { createRouter, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { users, profiles, farmerProfiles, interests, chats, contactInquiries, subscriptions } from "@db/schema";

export const adminRouter = createRouter({
  getStats: adminQuery.query(async () => {
    const db = getDb();

    const [totalUsers] = await db.select({ count: count() }).from(users);
    const [regularProfiles] = await db.select({ count: count() }).from(profiles);
    const [farmerProfilesCount] = await db.select({ count: count() }).from(farmerProfiles);
    const [pendingRegular] = await db
      .select({ count: count() })
      .from(profiles)
      .where(eq(profiles.isApproved, false));
    const [pendingFarmer] = await db
      .select({ count: count() })
      .from(farmerProfiles)
      .where(eq(farmerProfiles.isApproved, false));
    const [totalInterests] = await db.select({ count: count() }).from(interests);
    const [totalChats] = await db.select({ count: count() }).from(chats);
    const [newInquiries] = await db
      .select({ count: count() })
      .from(contactInquiries)
      .where(eq(contactInquiries.status, "new"));

    return {
      totalUsers: totalUsers?.count || 0,
      totalRegularProfiles: regularProfiles?.count || 0,
      totalFarmerProfiles: farmerProfilesCount?.count || 0,
      pendingApprovals: (pendingRegular?.count || 0) + (pendingFarmer?.count || 0),
      totalInterests: totalInterests?.count || 0,
      totalChats: totalChats?.count || 0,
      newInquiries: newInquiries?.count || 0,
    };
  }),

  getPendingProfiles: adminQuery.query(async () => {
    const db = getDb();
    const regularPending = await db
      .select({
        id: profiles.id,
        userId: profiles.userId,
        type: sql<string>`'regular'`.as("type"),
        name: users.name,
        email: users.email,
        gender: profiles.gender,
        age: profiles.age,
        religion: profiles.religion,
        city: profiles.city,
        state: profiles.state,
        createdAt: profiles.createdAt,
      })
      .from(profiles)
      .leftJoin(users, eq(profiles.userId, users.id))
      .where(eq(profiles.isApproved, false));

    const farmerPending = await db
      .select({
        id: farmerProfiles.id,
        userId: farmerProfiles.userId,
        type: sql<string>`'farmer'`.as("type"),
        name: users.name,
        email: users.email,
        gender: farmerProfiles.gender,
        age: farmerProfiles.age,
        religion: farmerProfiles.farmingType,
        city: farmerProfiles.village,
        state: farmerProfiles.state,
        createdAt: farmerProfiles.createdAt,
      })
      .from(farmerProfiles)
      .leftJoin(users, eq(farmerProfiles.userId, users.id))
      .where(eq(farmerProfiles.isApproved, false));

    return [...regularPending, ...farmerPending];
  }),

  getUsers: adminQuery.query(async () => {
    const db = getDb();
    const allUsers = await db
      .select({
        id: users.id,
        name: users.name,
        email: users.email,
        phone: users.phone,
        role: users.role,
        category: users.category,
        isVerified: users.isVerified,
        subscriptionPlan: users.subscriptionPlan,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(desc(users.createdAt));
    return allUsers;
  }),

  updateUserStatus: adminQuery
    .input(z.object({ id: z.number(), role: z.enum(["user", "admin"]) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [updated] = await db
        .update(users)
        .set({ role: input.role })
        .where(eq(users.id, input.id));
      return updated;
    }),

  getInquiries: adminQuery.query(async () => {
    const db = getDb();
    return db
      .select()
      .from(contactInquiries)
      .orderBy(desc(contactInquiries.createdAt));
  }),

  updateInquiryStatus: adminQuery
    .input(z.object({ id: z.number(), status: z.enum(["new", "read", "resolved"]) }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [updated] = await db
        .update(contactInquiries)
        .set({ status: input.status })
        .where(eq(contactInquiries.id, input.id));
      return updated;
    }),

  getSubscriptions: adminQuery.query(async () => {
    const db = getDb();
    return db
      .select({
        id: subscriptions.id,
        userId: subscriptions.userId,
        plan: subscriptions.plan,
        amount: subscriptions.amount,
        paymentStatus: subscriptions.paymentStatus,
        startDate: subscriptions.startDate,
        endDate: subscriptions.endDate,
        createdAt: subscriptions.createdAt,
        name: users.name,
        email: users.email,
      })
      .from(subscriptions)
      .leftJoin(users, eq(subscriptions.userId, users.id))
      .orderBy(desc(subscriptions.createdAt));
  }),
});
