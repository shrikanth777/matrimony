import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { chats, interests } from "@db/schema";

export const chatRouter = createRouter({
  getHistory: authedQuery
    .input(z.object({ interestId: z.number() }))
    .query(async ({ ctx, input }) => {
      const db = getDb();
      // Verify user is part of this interest
      const [interest] = await db
        .select()
        .from(interests)
        .where(eq(interests.id, input.interestId))
        .limit(1);

      if (!interest) return [];
      if (interest.senderId !== ctx.user.id && interest.receiverId !== ctx.user.id) {
        return [];
      }

      const messages = await db
        .select()
        .from(chats)
        .where(eq(chats.interestId, input.interestId))
        .orderBy(chats.createdAt);

      return messages;
    }),

  send: authedQuery
    .input(
      z.object({
        interestId: z.number(),
        receiverId: z.number(),
        message: z.string().min(1),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [chat] = await db.insert(chats).values({
        interestId: input.interestId,
        senderId: ctx.user.id,
        receiverId: input.receiverId,
        message: input.message,
      });
      return chat;
    }),

  markRead: authedQuery
    .input(z.object({ interestId: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      await db
        .update(chats)
        .set({ isRead: true })
        .where(
          and(
            eq(chats.interestId, input.interestId),
            eq(chats.receiverId, ctx.user.id)
          )
        );
      return { success: true };
    }),
});
