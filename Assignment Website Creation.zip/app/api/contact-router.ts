import { z } from "zod";
import { desc } from "drizzle-orm";
import { createRouter, publicQuery, adminQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { contactInquiries } from "@db/schema";

export const contactRouter = createRouter({
  submit: publicQuery
    .input(
      z.object({
        name: z.string().min(1),
        email: z.string().email(),
        phone: z.string().optional(),
        subject: z.string().optional(),
        message: z.string().min(1),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [inquiry] = await db.insert(contactInquiries).values(input);
      return inquiry;
    }),

  list: adminQuery.query(async () => {
    const db = getDb();
    return db
      .select()
      .from(contactInquiries)
      .orderBy(desc(contactInquiries.createdAt));
  }),
});
