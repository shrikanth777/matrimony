import { z } from "zod";
import { eq, and, like, sql } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { farmerProfiles, users } from "@db/schema";

export const farmerProfileRouter = createRouter({
  create: authedQuery
    .input(
      z.object({
        gender: z.enum(["male", "female", "other"]),
        age: z.number().min(18).max(80),
        farmingType: z.string().min(1),
        landSize: z.string().optional(),
        annualIncome: z.string().optional(),
        hasTractor: z.boolean().default(false),
        hasDairyPoultry: z.boolean().default(false),
        village: z.string().optional(),
        district: z.string().optional(),
        state: z.string().optional(),
        country: z.string().default("India"),
        aboutMe: z.string().optional(),
        photos: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db
        .select()
        .from(farmerProfiles)
        .where(eq(farmerProfiles.userId, ctx.user.id))
        .limit(1);

      if (existing.length > 0) {
        const [updated] = await db
          .update(farmerProfiles)
          .set({
            ...input,
            isProfileComplete: true,
            updatedAt: new Date(),
          })
          .where(eq(farmerProfiles.userId, ctx.user.id));
        return updated;
      }

      const [profile] = await db.insert(farmerProfiles).values({
        userId: ctx.user.id,
        ...input,
        isProfileComplete: true,
      });
      return profile;
    }),

  update: authedQuery
    .input(
      z.object({
        gender: z.enum(["male", "female", "other"]).optional(),
        age: z.number().min(18).max(80).optional(),
        farmingType: z.string().optional(),
        landSize: z.string().optional(),
        annualIncome: z.string().optional(),
        hasTractor: z.boolean().optional(),
        hasDairyPoultry: z.boolean().optional(),
        village: z.string().optional(),
        district: z.string().optional(),
        state: z.string().optional(),
        country: z.string().optional(),
        aboutMe: z.string().optional(),
        photos: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [updated] = await db
        .update(farmerProfiles)
        .set({ ...input, updatedAt: new Date() })
        .where(eq(farmerProfiles.userId, ctx.user.id));
      return updated;
    }),

  getMyProfile: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const [profile] = await db
      .select()
      .from(farmerProfiles)
      .where(eq(farmerProfiles.userId, ctx.user.id))
      .limit(1);
    return profile || null;
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [profile] = await db
        .select()
        .from(farmerProfiles)
        .where(eq(farmerProfiles.id, input.id))
        .limit(1);
      return profile || null;
    }),

  search: publicQuery
    .input(
      z.object({
        gender: z.enum(["male", "female", "other"]).optional(),
        minAge: z.number().optional(),
        maxAge: z.number().optional(),
        farmingType: z.string().optional(),
        state: z.string().optional(),
        district: z.string().optional(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input.gender) conditions.push(eq(farmerProfiles.gender, input.gender));
      if (input.minAge) conditions.push(sql`${farmerProfiles.age} >= ${input.minAge}`);
      if (input.maxAge) conditions.push(sql`${farmerProfiles.age} <= ${input.maxAge}`);
      if (input.farmingType) conditions.push(like(farmerProfiles.farmingType, `%${input.farmingType}%`));
      if (input.state) conditions.push(like(farmerProfiles.state, `%${input.state}%`));
      if (input.district) conditions.push(like(farmerProfiles.district, `%${input.district}%`));

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const results = await db
        .select({
          id: farmerProfiles.id,
          userId: farmerProfiles.userId,
          gender: farmerProfiles.gender,
          age: farmerProfiles.age,
          farmingType: farmerProfiles.farmingType,
          landSize: farmerProfiles.landSize,
          annualIncome: farmerProfiles.annualIncome,
          hasTractor: farmerProfiles.hasTractor,
          hasDairyPoultry: farmerProfiles.hasDairyPoultry,
          village: farmerProfiles.village,
          district: farmerProfiles.district,
          state: farmerProfiles.state,
          aboutMe: farmerProfiles.aboutMe,
          photos: farmerProfiles.photos,
          name: users.name,
        })
        .from(farmerProfiles)
        .leftJoin(users, eq(farmerProfiles.userId, users.id))
        .where(whereClause)
        .limit(input.limit)
        .offset(input.offset);

      return results;
    }),

  list: publicQuery.query(async () => {
    const db = getDb();
    const results = await db
      .select({
        id: farmerProfiles.id,
        userId: farmerProfiles.userId,
        gender: farmerProfiles.gender,
        age: farmerProfiles.age,
        farmingType: farmerProfiles.farmingType,
        landSize: farmerProfiles.landSize,
        village: farmerProfiles.village,
        district: farmerProfiles.district,
        state: farmerProfiles.state,
        isApproved: farmerProfiles.isApproved,
        isProfileComplete: farmerProfiles.isProfileComplete,
        name: users.name,
        email: users.email,
      })
      .from(farmerProfiles)
      .leftJoin(users, eq(farmerProfiles.userId, users.id));
    return results;
  }),

  approve: authedQuery
    .input(z.object({ id: z.number(), approve: z.boolean() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [updated] = await db
        .update(farmerProfiles)
        .set({ isApproved: input.approve, updatedAt: new Date() })
        .where(eq(farmerProfiles.id, input.id));
      return updated;
    }),
});
