import { z } from "zod";
import { eq, and } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { interests, users } from "@db/schema";

export const interestRouter = createRouter({
  send: authedQuery
    .input(
      z.object({
        receiverId: z.number(),
        message: z.string().optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [interest] = await db.insert(interests).values({
        senderId: ctx.user.id,
        receiverId: input.receiverId,
        message: input.message || null,
      });
      return interest;
    }),

  accept: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [updated] = await db
        .update(interests)
        .set({ status: "accepted", updatedAt: new Date() })
        .where(
          and(
            eq(interests.id, input.id),
            eq(interests.receiverId, ctx.user.id)
          )
        );
      return updated;
    }),

  reject: authedQuery
    .input(z.object({ id: z.number() }))
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [updated] = await db
        .update(interests)
        .set({ status: "rejected", updatedAt: new Date() })
        .where(
          and(
            eq(interests.id, input.id),
            eq(interests.receiverId, ctx.user.id)
          )
        );
      return updated;
    }),

  listSent: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const results = await db
      .select({
        id: interests.id,
        receiverId: interests.receiverId,
        status: interests.status,
        message: interests.message,
        createdAt: interests.createdAt,
        receiverName: users.name,
      })
      .from(interests)
      .leftJoin(users, eq(interests.receiverId, users.id))
      .where(eq(interests.senderId, ctx.user.id));
    return results;
  }),

  listReceived: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const results = await db
      .select({
        id: interests.id,
        senderId: interests.senderId,
        status: interests.status,
        message: interests.message,
        createdAt: interests.createdAt,
        senderName: users.name,
      })
      .from(interests)
      .leftJoin(users, eq(interests.senderId, users.id))
      .where(eq(interests.receiverId, ctx.user.id));
    return results;
  }),

  myMatches: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    // Get all accepted interests where user is either sender or receiver
    const sentMatches = await db
      .select({
        id: interests.id,
        otherId: interests.receiverId,
        createdAt: interests.createdAt,
        otherName: users.name,
      })
      .from(interests)
      .leftJoin(users, eq(interests.receiverId, users.id))
      .where(
        and(
          eq(interests.senderId, ctx.user.id),
          eq(interests.status, "accepted")
        )
      );

    const receivedMatches = await db
      .select({
        id: interests.id,
        otherId: interests.senderId,
        createdAt: interests.createdAt,
        otherName: users.name,
      })
      .from(interests)
      .leftJoin(users, eq(interests.senderId, users.id))
      .where(
        and(
          eq(interests.receiverId, ctx.user.id),
          eq(interests.status, "accepted")
        )
      );

    return [...sentMatches, ...receivedMatches];
  }),
});
