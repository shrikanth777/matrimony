import { eq, and, sql } from "drizzle-orm";
import { createRouter, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { profiles, farmerProfiles, interests, users } from "@db/schema";

export const matchRouter = createRouter({
  getSuggestions: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const userId = ctx.user.id;
    const userCategory = ctx.user.category;

    // Get the current user's profile
    let myProfile;
    if (userCategory === "farmer") {
      const [fp] = await db
        .select()
        .from(farmerProfiles)
        .where(eq(farmerProfiles.userId, userId))
        .limit(1);
      myProfile = fp;
    } else {
      const [rp] = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, userId))
        .limit(1);
      myProfile = rp;
    }

    if (!myProfile) return [];

    // Get existing interest IDs to exclude
    const existingInterests = await db
      .select()
      .from(interests)
      .where(
        or(
          eq(interests.senderId, userId),
          eq(interests.receiverId, userId)
        )
      );

    const excludedUserIds = new Set([userId]);
    for (const interest of existingInterests) {
      excludedUserIds.add(interest.senderId);
      excludedUserIds.add(interest.receiverId);
    }

    // Search for compatible matches based on category
    if (userCategory === "farmer") {
      const results = await db
        .select({
          id: farmerProfiles.id,
          userId: farmerProfiles.userId,
          gender: farmerProfiles.gender,
          age: farmerProfiles.age,
          farmingType: farmerProfiles.farmingType,
          landSize: farmerProfiles.landSize,
          annualIncome: farmerProfiles.annualIncome,
          hasTractor: farmerProfiles.hasTractor,
          hasDairyPoultry: farmerProfiles.hasDairyPoultry,
          village: farmerProfiles.village,
          district: farmerProfiles.district,
          state: farmerProfiles.state,
          aboutMe: farmerProfiles.aboutMe,
          photos: farmerProfiles.photos,
          name: users.name,
        })
        .from(farmerProfiles)
        .leftJoin(users, eq(farmerProfiles.userId, users.id))
        .where(
          and(
            sql`${farmerProfiles.gender} != ${myProfile.gender}`,
            eq(farmerProfiles.isApproved, true),
            eq(farmerProfiles.isProfileComplete, true)
          )
        )
        .limit(10);

      // Filter out excluded users and score matches
      return results
        .filter((r) => !excludedUserIds.has(r.userId))
        .map((r) => ({
          ...r,
          matchScore: calculateFarmerMatchScore(myProfile, r),
        }))
        .sort((a, b) => b.matchScore - a.matchScore);
    } else {
      const conditions = [
        sql`${profiles.gender} != ${myProfile.gender}`,
        eq(profiles.isApproved, true),
        eq(profiles.isProfileComplete, true),
      ];

      const results = await db
        .select({
          id: profiles.id,
          userId: profiles.userId,
          gender: profiles.gender,
          age: profiles.age,
          religion: profiles.religion,
          caste: profiles.caste,
          education: profiles.education,
          profession: profiles.profession,
          salaryRange: profiles.salaryRange,
          city: profiles.city,
          state: profiles.state,
          aboutMe: profiles.aboutMe,
          photos: profiles.photos,
          name: users.name,
        })
        .from(profiles)
        .leftJoin(users, eq(profiles.userId, users.id))
        .where(and(...conditions))
        .limit(10);

      return results
        .filter((r) => !excludedUserIds.has(r.userId))
        .map((r) => ({
          ...r,
          matchScore: calculateRegularMatchScore(myProfile, r),
        }))
        .sort((a, b) => b.matchScore - a.matchScore);
    }
  }),
});

function calculateRegularMatchScore(myProfile: any, match: any): number {
  let score = 50; // Base score
  if (myProfile.religion && match.religion && myProfile.religion === match.religion) score += 20;
  if (myProfile.state && match.state && myProfile.state === match.state) score += 15;
  if (myProfile.education && match.education && myProfile.education === match.education) score += 10;
  if (myProfile.profession && match.profession && myProfile.profession === match.profession) score += 5;
  const ageDiff = Math.abs(myProfile.age - match.age);
  if (ageDiff <= 5) score += 10;
  else if (ageDiff <= 10) score += 5;
  return Math.min(score, 100);
}

function calculateFarmerMatchScore(myProfile: any, match: any): number {
  let score = 50;
  if (myProfile.farmingType && match.farmingType && myProfile.farmingType === match.farmingType) score += 20;
  if (myProfile.state && match.state && myProfile.state === match.state) score += 15;
  if (myProfile.district && match.district && myProfile.district === match.district) score += 10;
  const ageDiff = Math.abs(myProfile.age - match.age);
  if (ageDiff <= 5) score += 10;
  else if (ageDiff <= 10) score += 5;
  return Math.min(score, 100);
}

// Helper for OR conditions
function or(...conditions: any[]) {
  return sql`(${conditions.join(" OR ")})`;
}
