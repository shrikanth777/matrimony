import { z } from "zod";
import { eq, and, like, sql } from "drizzle-orm";
import { createRouter, publicQuery, authedQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { profiles, users } from "@db/schema";

export const profileRouter = createRouter({
  create: authedQuery
    .input(
      z.object({
        gender: z.enum(["male", "female", "other"]),
        age: z.number().min(18).max(80),
        religion: z.string().optional(),
        caste: z.string().optional(),
        education: z.string().optional(),
        profession: z.string().optional(),
        salaryRange: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        country: z.string().default("India"),
        aboutMe: z.string().optional(),
        photos: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const existing = await db
        .select()
        .from(profiles)
        .where(eq(profiles.userId, ctx.user.id))
        .limit(1);

      if (existing.length > 0) {
        const [updated] = await db
          .update(profiles)
          .set({
            ...input,
            isProfileComplete: true,
            updatedAt: new Date(),
          })
          .where(eq(profiles.userId, ctx.user.id));
        return updated;
      }

      const [profile] = await db.insert(profiles).values({
        userId: ctx.user.id,
        ...input,
        isProfileComplete: true,
      });
      return profile;
    }),

  update: authedQuery
    .input(
      z.object({
        gender: z.enum(["male", "female", "other"]).optional(),
        age: z.number().min(18).max(80).optional(),
        religion: z.string().optional(),
        caste: z.string().optional(),
        education: z.string().optional(),
        profession: z.string().optional(),
        salaryRange: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        country: z.string().optional(),
        aboutMe: z.string().optional(),
        photos: z.array(z.string()).optional(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();
      const [updated] = await db
        .update(profiles)
        .set({ ...input, updatedAt: new Date() })
        .where(eq(profiles.userId, ctx.user.id));
      return updated;
    }),

  getMyProfile: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const [profile] = await db
      .select()
      .from(profiles)
      .where(eq(profiles.userId, ctx.user.id))
      .limit(1);
    return profile || null;
  }),

  getById: publicQuery
    .input(z.object({ id: z.number() }))
    .query(async ({ input }) => {
      const db = getDb();
      const [profile] = await db
        .select()
        .from(profiles)
        .where(eq(profiles.id, input.id))
        .limit(1);
      return profile || null;
    }),

  search: publicQuery
    .input(
      z.object({
        gender: z.enum(["male", "female", "other"]).optional(),
        minAge: z.number().optional(),
        maxAge: z.number().optional(),
        religion: z.string().optional(),
        caste: z.string().optional(),
        education: z.string().optional(),
        profession: z.string().optional(),
        city: z.string().optional(),
        state: z.string().optional(),
        limit: z.number().default(20),
        offset: z.number().default(0),
      })
    )
    .query(async ({ input }) => {
      const db = getDb();
      const conditions = [];

      if (input.gender) conditions.push(eq(profiles.gender, input.gender));
      if (input.minAge) conditions.push(sql`${profiles.age} >= ${input.minAge}`);
      if (input.maxAge) conditions.push(sql`${profiles.age} <= ${input.maxAge}`);
      if (input.religion) conditions.push(eq(profiles.religion, input.religion));
      if (input.caste) conditions.push(eq(profiles.caste, input.caste));
      if (input.education) conditions.push(like(profiles.education, `%${input.education}%`));
      if (input.profession) conditions.push(like(profiles.profession, `%${input.profession}%`));
      if (input.city) conditions.push(like(profiles.city, `%${input.city}%`));
      if (input.state) conditions.push(like(profiles.state, `%${input.state}%`));

      const whereClause = conditions.length > 0 ? and(...conditions) : undefined;

      const results = await db
        .select({
          id: profiles.id,
          userId: profiles.userId,
          gender: profiles.gender,
          age: profiles.age,
          religion: profiles.religion,
          caste: profiles.caste,
          education: profiles.education,
          profession: profiles.profession,
          salaryRange: profiles.salaryRange,
          city: profiles.city,
          state: profiles.state,
          aboutMe: profiles.aboutMe,
          photos: profiles.photos,
          name: users.name,
        })
        .from(profiles)
        .leftJoin(users, eq(profiles.userId, users.id))
        .where(whereClause)
        .limit(input.limit)
        .offset(input.offset);

      return results;
    }),

  list: publicQuery.query(async () => {
    const db = getDb();
    const results = await db
      .select({
        id: profiles.id,
        userId: profiles.userId,
        gender: profiles.gender,
        age: profiles.age,
        religion: profiles.religion,
        caste: profiles.caste,
        education: profiles.education,
        profession: profiles.profession,
        city: profiles.city,
        state: profiles.state,
        isApproved: profiles.isApproved,
        isProfileComplete: profiles.isProfileComplete,
        name: users.name,
        email: users.email,
      })
      .from(profiles)
      .leftJoin(users, eq(profiles.userId, users.id));
    return results;
  }),

  approve: authedQuery
    .input(z.object({ id: z.number(), approve: z.boolean() }))
    .mutation(async ({ input }) => {
      const db = getDb();
      const [updated] = await db
        .update(profiles)
        .set({ isApproved: input.approve, updatedAt: new Date() })
        .where(eq(profiles.id, input.id));
      return updated;
    }),
});
