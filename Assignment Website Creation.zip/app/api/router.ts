import { authRouter } from "./auth-router";
import { profileRouter } from "./profile-router";
import { farmerProfileRouter } from "./farmer-profile-router";
import { interestRouter } from "./interest-router";
import { matchRouter } from "./match-router";
import { chatRouter } from "./chat-router";
import { notificationRouter } from "./notification-router";
import { subscriptionRouter } from "./subscription-router";
import { adminRouter } from "./admin-router";
import { successStoryRouter } from "./success-story-router";
import { contactRouter } from "./contact-router";
import { createRouter, publicQuery } from "./middleware";

export const appRouter = createRouter({
  ping: publicQuery.query(() => ({ ok: true, ts: Date.now() })),
  auth: authRouter,
  profile: profileRouter,
  farmerProfile: farmerProfileRouter,
  interest: interestRouter,
  match: matchRouter,
  chat: chatRouter,
  notification: notificationRouter,
  subscription: subscriptionRouter,
  admin: adminRouter,
  successStory: successStoryRouter,
  contact: contactRouter,
});

export type AppRouter = typeof appRouter;
