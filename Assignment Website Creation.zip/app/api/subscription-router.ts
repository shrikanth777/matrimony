import { z } from "zod";
import { eq, desc } from "drizzle-orm";
import { createRouter, authedQuery, adminQuery, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { subscriptions, users } from "@db/schema";

export const subscriptionRouter = createRouter({
  getPlans: publicQuery.query(() => {
    return [
      {
        id: "free",
        name: "Free",
        price: 0,
        duration: "Lifetime",
        features: [
          "Create profile",
          "Browse limited matches",
          "Send 1 interest per day",
        ],
      },
      {
        id: "silver",
        name: "Silver",
        price: 999,
        duration: "3 Months",
        features: [
          "All Free features",
          "Browse unlimited matches",
          "Send 10 interests per day",
          "View contact details",
        ],
      },
      {
        id: "gold",
        name: "Gold",
        price: 1999,
        duration: "6 Months",
        features: [
          "All Silver features",
          "Unlimited interests",
          "Priority profile listing",
          "Chat with matches",
          "AI match suggestions",
        ],
      },
      {
        id: "platinum",
        name: "Platinum",
        price: 3499,
        duration: "12 Months",
        features: [
          "All Gold features",
          "Personal matchmaker",
          "Profile highlighting",
          "Video call support",
          "Premium badge",
        ],
      },
    ];
  }),

  subscribe: authedQuery
    .input(
      z.object({
        plan: z.enum(["free", "silver", "gold", "platinum"]),
        amount: z.number(),
      })
    )
    .mutation(async ({ ctx, input }) => {
      const db = getDb();

      // Calculate end date based on plan
      const startDate = new Date();
      const endDate = new Date();
      switch (input.plan) {
        case "silver":
          endDate.setMonth(endDate.getMonth() + 3);
          break;
        case "gold":
          endDate.setMonth(endDate.getMonth() + 6);
          break;
        case "platinum":
          endDate.setMonth(endDate.getMonth() + 12);
          break;
        default:
          endDate.setFullYear(endDate.getFullYear() + 10);
      }

      const [subscription] = await db.insert(subscriptions).values({
        userId: ctx.user.id,
        plan: input.plan,
        amount: input.amount.toString(),
        paymentStatus: "completed",
        startDate,
        endDate,
      });

      // Update user's subscription
      await db
        .update(users)
        .set({
          subscriptionPlan: input.plan,
          subscriptionExpiry: endDate,
        })
        .where(eq(users.id, ctx.user.id));

      return subscription;
    }),

  getCurrent: authedQuery.query(async ({ ctx }) => {
    const db = getDb();
    const [subscription] = await db
      .select()
      .from(subscriptions)
      .where(eq(subscriptions.userId, ctx.user.id))
      .orderBy(desc(subscriptions.createdAt))
      .limit(1);
    return subscription || null;
  }),

  list: adminQuery.query(async () => {
    const db = getDb();
    return db
      .select()
      .from(subscriptions)
      .orderBy(desc(subscriptions.createdAt));
  }),
});
