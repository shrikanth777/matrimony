import { z } from "zod";
import { desc } from "drizzle-orm";
import { createRouter, publicQuery } from "./middleware";
import { getDb } from "./queries/connection";
import { successStories } from "@db/schema";

export const successStoryRouter = createRouter({
  list: publicQuery.query(async () => {
    const db = getDb();
    return db
      .select()
      .from(successStories)
      .orderBy(desc(successStories.createdAt));
  }),

  create: publicQuery
    .input(
      z.object({
        coupleName: z.string().min(1),
        story: z.string().min(1),
        photo: z.string().optional(),
        category: z.enum(["regular", "farmer"]),
      })
    )
    .mutation(async ({ input }) => {
      const db = getDb();
      const [story] = await db.insert(successStories).values(input);
      return story;
    }),
});
