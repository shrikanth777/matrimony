// Relations for the AI Matrimony platform
// Currently using simple foreign key references in queries
// Add explicit relations here if needed for complex query patterns
