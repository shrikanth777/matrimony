import {
  mysqlTable,
  mysqlEnum,
  serial,
  varchar,
  text,
  timestamp,
  int,
  boolean,
  json,
  decimal,
  bigint,
} from "drizzle-orm/mysql-core";

// ─── Users ────────────────────────────────────────────────
export const users = mysqlTable("users", {
  id: serial("id").primaryKey(),
  unionId: varchar("unionId", { length: 255 }).notNull().unique(),
  email: varchar("email", { length: 320 }),
  phone: varchar("phone", { length: 20 }),
  passwordHash: varchar("passwordHash", { length: 255 }),
  name: varchar("name", { length: 255 }),
  avatar: text("avatar"),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  category: mysqlEnum("category", ["regular", "farmer"]).default("regular").notNull(),
  isVerified: boolean("isVerified").default(false),
  isEmailVerified: boolean("isEmailVerified").default(false),
  isPhoneVerified: boolean("isPhoneVerified").default(false),
  subscriptionPlan: mysqlEnum("subscriptionPlan", ["free", "silver", "gold", "platinum"]).default("free"),
  subscriptionExpiry: timestamp("subscriptionExpiry"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
  lastSignInAt: timestamp("lastSignInAt").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// ─── Regular Profiles ─────────────────────────────────────
export const profiles = mysqlTable("profiles", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  gender: mysqlEnum("gender", ["male", "female", "other"]).notNull(),
  age: int("age").notNull(),
  religion: varchar("religion", { length: 50 }),
  caste: varchar("caste", { length: 50 }),
  education: varchar("education", { length: 100 }),
  profession: varchar("profession", { length: 100 }),
  salaryRange: varchar("salaryRange", { length: 50 }),
  city: varchar("city", { length: 100 }),
  state: varchar("state", { length: 100 }),
  country: varchar("country", { length: 100 }).default("India"),
  aboutMe: text("aboutMe"),
  photos: json("photos").$type<string[]>(),
  isProfileComplete: boolean("isProfileComplete").default(false),
  isApproved: boolean("isApproved").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Profile = typeof profiles.$inferSelect;
export type InsertProfile = typeof profiles.$inferInsert;

// ─── Farmer Profiles ──────────────────────────────────────
export const farmerProfiles = mysqlTable("farmerProfiles", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  gender: mysqlEnum("gender", ["male", "female", "other"]).notNull(),
  age: int("age").notNull(),
  farmingType: varchar("farmingType", { length: 100 }).notNull(),
  landSize: varchar("landSize", { length: 50 }),
  annualIncome: varchar("annualIncome", { length: 50 }),
  hasTractor: boolean("hasTractor").default(false),
  hasDairyPoultry: boolean("hasDairyPoultry").default(false),
  village: varchar("village", { length: 100 }),
  district: varchar("district", { length: 100 }),
  state: varchar("state", { length: 100 }),
  country: varchar("country", { length: 100 }).default("India"),
  aboutMe: text("aboutMe"),
  photos: json("photos").$type<string[]>(),
  isProfileComplete: boolean("isProfileComplete").default(false),
  isApproved: boolean("isApproved").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type FarmerProfile = typeof farmerProfiles.$inferSelect;
export type InsertFarmerProfile = typeof farmerProfiles.$inferInsert;

// ─── Interests ────────────────────────────────────────────
export const interests = mysqlTable("interests", {
  id: serial("id").primaryKey(),
  senderId: bigint("senderId", { mode: "number", unsigned: true }).notNull(),
  receiverId: bigint("receiverId", { mode: "number", unsigned: true }).notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "rejected"]).default("pending").notNull(),
  message: text("message"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().notNull().$onUpdate(() => new Date()),
});

export type Interest = typeof interests.$inferSelect;
export type InsertInterest = typeof interests.$inferInsert;

// ─── Chats ────────────────────────────────────────────────
export const chats = mysqlTable("chats", {
  id: serial("id").primaryKey(),
  interestId: bigint("interestId", { mode: "number", unsigned: true }).notNull(),
  senderId: bigint("senderId", { mode: "number", unsigned: true }).notNull(),
  receiverId: bigint("receiverId", { mode: "number", unsigned: true }).notNull(),
  message: text("message").notNull(),
  isRead: boolean("isRead").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Chat = typeof chats.$inferSelect;
export type InsertChat = typeof chats.$inferInsert;

// ─── Notifications ────────────────────────────────────────
export const notifications = mysqlTable("notifications", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  type: mysqlEnum("type", ["interest", "message", "match", "system"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  isRead: boolean("isRead").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

// ─── Subscriptions ────────────────────────────────────────
export const subscriptions = mysqlTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: bigint("userId", { mode: "number", unsigned: true }).notNull(),
  plan: mysqlEnum("plan", ["free", "silver", "gold", "platinum"]).notNull(),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  paymentStatus: mysqlEnum("paymentStatus", ["pending", "completed", "failed"]).default("pending"),
  startDate: timestamp("startDate"),
  endDate: timestamp("endDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Subscription = typeof subscriptions.$inferSelect;
export type InsertSubscription = typeof subscriptions.$inferInsert;

// ─── Success Stories ──────────────────────────────────────
export const successStories = mysqlTable("successStories", {
  id: serial("id").primaryKey(),
  coupleName: varchar("coupleName", { length: 200 }).notNull(),
  story: text("story").notNull(),
  photo: varchar("photo", { length: 255 }),
  category: mysqlEnum("category", ["regular", "farmer"]).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type SuccessStory = typeof successStories.$inferSelect;
export type InsertSuccessStory = typeof successStories.$inferInsert;

// ─── Contact Inquiries ────────────────────────────────────
export const contactInquiries = mysqlTable("contactInquiries", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }).notNull(),
  phone: varchar("phone", { length: 20 }),
  subject: varchar("subject", { length: 200 }),
  message: text("message").notNull(),
  status: mysqlEnum("status", ["new", "read", "resolved"]).default("new"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type ContactInquiry = typeof contactInquiries.$inferSelect;
export type InsertContactInquiry = typeof contactInquiries.$inferInsert;
