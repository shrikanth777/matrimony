import { Routes, Route } from 'react-router'
import Home from './pages/Home'
import Login from './pages/Login'
import NotFound from './pages/NotFound'
import Register from './pages/Register'
import ProfileSetup from './pages/ProfileSetup'
import Search from './pages/Search'
import Dashboard from './pages/Dashboard'
import AdminDashboard from './pages/AdminDashboard'
import Matches from './pages/Matches'
import Chat from './pages/Chat'
import SubscriptionPlans from './pages/SubscriptionPlans'

export default function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route path="/profile-setup" element={<ProfileSetup />} />
      <Route path="/search" element={<Search />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/admin" element={<AdminDashboard />} />
      <Route path="/matches" element={<Matches />} />
      <Route path="/chat/:interestId" element={<Chat />} />
      <Route path="/subscription" element={<SubscriptionPlans />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  )
}
