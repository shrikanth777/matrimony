import { useState, useEffect } from 'react';
import { Link } from 'react-router';
import { useAuth } from '@/hooks/useAuth';
import { Menu, X, Heart, LogOut, User, Shield } from 'lucide-react';

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { user, isAuthenticated, logout } = useAuth();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 100);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
      setIsMobileMenuOpen(false);
    }
  };

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? 'bg-[#f4f2ec]/95 backdrop-blur-sm shadow-sm'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 lg:px-10">
        <div className="flex items-center justify-between h-16 lg:h-20">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-[#020202]" />
            <span className="font-['Playfair_Display'] text-xl font-medium tracking-tight">
              AVMatrimony
            </span>
          </Link>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center gap-8">
            <button
              onClick={() => scrollToSection('hero')}
              className="text-xs uppercase tracking-[0.1em] text-[#020202] hover:text-[#8a8a8a] transition-colors"
            >
              Home
            </button>
            <button
              onClick={() => scrollToSection('features')}
              className="text-xs uppercase tracking-[0.1em] text-[#020202] hover:text-[#8a8a8a] transition-colors"
            >
              About Us
            </button>
            <button
              onClick={() => scrollToSection('plans')}
              className="text-xs uppercase tracking-[0.1em] text-[#020202] hover:text-[#8a8a8a] transition-colors"
            >
              Premium
            </button>
            <button
              onClick={() => scrollToSection('contact')}
              className="text-xs uppercase tracking-[0.1em] text-[#020202] hover:text-[#8a8a8a] transition-colors"
            >
              Contact Us
            </button>
          </div>

          {/* Right Actions */}
          <div className="hidden lg:flex items-center gap-4">
            {isAuthenticated ? (
              <>
                {user?.role === 'admin' && (
                  <Link
                    to="/admin"
                    className="flex items-center gap-1 text-xs uppercase tracking-[0.1em] text-[#020202] hover:text-[#8a8a8a] transition-colors"
                  >
                    <Shield className="w-4 h-4" />
                    Admin
                  </Link>
                )}
                <Link
                  to="/dashboard"
                  className="flex items-center gap-1 text-xs uppercase tracking-[0.1em] text-[#020202] hover:text-[#8a8a8a] transition-colors"
                >
                  <User className="w-4 h-4" />
                  {user?.name || 'Dashboard'}
                </Link>
                <button
                  onClick={logout}
                  className="flex items-center gap-1 text-xs uppercase tracking-[0.1em] text-[#8a8a8a] hover:text-[#020202] transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                </button>
              </>
            ) : (
              <>
                <Link
                  to="/login"
                  className="text-xs uppercase tracking-[0.1em] text-[#020202] hover:text-[#8a8a8a] transition-colors"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="bg-[#020202] text-[#fcfbfa] px-6 py-2.5 rounded-full text-xs uppercase tracking-[0.1em] hover:bg-[#333] transition-colors"
                >
                  Get Started
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2"
          >
            {isMobileMenuOpen ? (
              <X className="w-5 h-5" />
            ) : (
              <Menu className="w-5 h-5" />
            )}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-[#f4f2ec]/95 backdrop-blur-sm border-t border-[#e6e6e2]">
          <div className="px-6 py-6 space-y-4">
            <button onClick={() => scrollToSection('hero')} className="block text-sm uppercase tracking-[0.1em]">Home</button>
            <button onClick={() => scrollToSection('features')} className="block text-sm uppercase tracking-[0.1em]">About Us</button>
            <button onClick={() => scrollToSection('plans')} className="block text-sm uppercase tracking-[0.1em]">Premium</button>
            <button onClick={() => scrollToSection('contact')} className="block text-sm uppercase tracking-[0.1em]">Contact Us</button>
            <hr className="border-[#e6e6e2]" />
            {isAuthenticated ? (
              <>
                <Link to="/dashboard" onClick={() => setIsMobileMenuOpen(false)} className="block text-sm uppercase tracking-[0.1em]">Dashboard</Link>
                {user?.role === 'admin' && (
                  <Link to="/admin" onClick={() => setIsMobileMenuOpen(false)} className="block text-sm uppercase tracking-[0.1em]">Admin Panel</Link>
                )}
                <button onClick={() => { logout(); setIsMobileMenuOpen(false); }} className="block text-sm uppercase tracking-[0.1em] text-[#8a8a8a]">Logout</button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={() => setIsMobileMenuOpen(false)} className="block text-sm uppercase tracking-[0.1em]">Login</Link>
                <Link to="/register" onClick={() => setIsMobileMenuOpen(false)} className="block text-sm uppercase tracking-[0.1em] bg-[#020202] text-[#fcfbfa] px-6 py-2.5 rounded-full text-center">Get Started</Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  );
}
