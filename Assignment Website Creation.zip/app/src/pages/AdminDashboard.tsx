import { useState } from 'react';
import { Link } from 'react-router';
import { Heart, Users, UserCheck, MessageSquare, Mail, Shield, CheckCircle, XCircle, Eye } from 'lucide-react';

const stats = [
  { label: 'Total Users', value: 1248, icon: Users },
  { label: 'Regular Profiles', value: 892, icon: UserCheck },
  { label: 'Farmer Profiles', value: 356, icon: Shield },
  { label: 'Pending Approvals', value: 24, icon: Eye },
  { label: 'Total Interests', value: 3456, icon: MessageSquare },
  { label: 'New Inquiries', value: 18, icon: Mail },
];

const pendingProfiles = [
  { id: 1, name: 'Amit Kumar', type: 'regular', gender: 'Male', age: 28, religion: 'Hindu', city: 'Delhi', submitted: '2026-06-12' },
  { id: 2, name: 'Sunita Devi', type: 'farmer', gender: 'Female', age: 24, religion: 'Hindu', city: 'Patna', submitted: '2026-06-11' },
  { id: 3, name: 'Rohan Mehta', type: 'regular', gender: 'Male', age: 30, religion: 'Jain', city: 'Mumbai', submitted: '2026-06-10' },
  { id: 4, name: 'Geeta Patel', type: 'farmer', gender: 'Female', age: 26, religion: 'Hindu', city: 'Ahmedabad', submitted: '2026-06-09' },
];

const inquiries = [
  { id: 1, name: 'Rajesh Kumar', email: 'rajesh@email.com', subject: 'Payment Issue', status: 'new', date: '2026-06-13' },
  { id: 2, name: 'Priya Singh', email: 'priya@email.com', subject: 'Profile Verification', status: 'read', date: '2026-06-12' },
  { id: 3, name: 'Amit Patel', email: 'amit@email.com', subject: 'Subscription Query', status: 'resolved', date: '2026-06-11' },
];

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState<'overview' | 'profiles' | 'inquiries' | 'users'>('overview');

  return (
    <div className="min-h-screen bg-[#f4f2ec]">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link to="/" className="flex items-center gap-2">
              <Heart className="w-5 h-5" />
              <span className="font-['Playfair_Display'] text-lg">AVMatrimony</span>
            </Link>
            <span className="px-3 py-1 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-wider">Admin Panel</span>
          </div>
          <Link to="/dashboard" className="text-sm text-[#8a8a8a] hover:text-[#020202]">My Dashboard</Link>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-8 overflow-x-auto">
          {(['overview', 'profiles', 'inquiries', 'users'] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`px-4 py-2 text-xs uppercase tracking-[0.1em] border transition-colors whitespace-nowrap ${
                activeTab === tab ? 'bg-[#020202] text-[#fcfbfa] border-[#020202]' : 'border-[#e6e6e2] hover:border-[#020202]'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {activeTab === 'overview' && (
          <>
            {/* Stats Grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mb-8">
              {stats.map((stat, i) => {
                const Icon = stat.icon;
                return (
                  <div key={i} className="border border-[#e6e6e2] p-4 text-center">
                    <Icon className="w-5 h-5 mx-auto mb-2 text-[#020202]" />
                    <p className="text-2xl font-['Playfair_Display']">{stat.value.toLocaleString()}</p>
                    <p className="text-xs text-[#8a8a8a] uppercase tracking-wider">{stat.label}</p>
                  </div>
                );
              })}
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <div className="border border-[#e6e6e2] p-6">
                <h3 className="text-lg font-['Playfair_Display'] mb-4">Pending Approvals</h3>
                <div className="space-y-3">
                  {pendingProfiles.slice(0, 3).map((profile) => (
                    <div key={profile.id} className="flex items-center justify-between p-3 border border-[#e6e6e2]">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-[#e6e6e2] flex items-center justify-center text-sm font-['Playfair_Display']">
                          {profile.name.charAt(0)}
                        </div>
                        <div>
                          <p className="text-sm font-medium">{profile.name}</p>
                          <p className="text-xs text-[#8a8a8a]">{profile.type} | {profile.age} yrs | {profile.city}</p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <button className="p-1.5 hover:bg-green-50 transition-colors">
                          <CheckCircle className="w-4 h-4 text-green-600" />
                        </button>
                        <button className="p-1.5 hover:bg-red-50 transition-colors">
                          <XCircle className="w-4 h-4 text-red-600" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="border border-[#e6e6e2] p-6">
                <h3 className="text-lg font-['Playfair_Display'] mb-4">Recent Inquiries</h3>
                <div className="space-y-3">
                  {inquiries.map((inquiry) => (
                    <div key={inquiry.id} className="flex items-center justify-between p-3 border border-[#e6e6e2]">
                      <div>
                        <p className="text-sm font-medium">{inquiry.name}</p>
                        <p className="text-xs text-[#8a8a8a]">{inquiry.subject}</p>
                      </div>
                      <span className={`text-xs uppercase tracking-wider px-2 py-1 ${
                        inquiry.status === 'new' ? 'bg-[#020202] text-[#fcfbfa]' :
                        inquiry.status === 'read' ? 'bg-[#e6e6e2] text-[#8a8a8a]' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {inquiry.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </>
        )}

        {activeTab === 'profiles' && (
          <div className="border border-[#e6e6e2]">
            <div className="p-4 border-b border-[#e6e6e2]">
              <h3 className="text-lg font-['Playfair_Display']">Profile Approvals</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#e6e6e2]">
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Name</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Type</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Age</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Location</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Submitted</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pendingProfiles.map((profile) => (
                    <tr key={profile.id} className="border-b border-[#e6e6e2] hover:bg-[#fcfbfa]">
                      <td className="p-4 text-sm">{profile.name}</td>
                      <td className="p-4">
                        <span className="text-xs uppercase tracking-wider px-2 py-1 bg-[#e6e6e2]">{profile.type}</span>
                      </td>
                      <td className="p-4 text-sm">{profile.age}</td>
                      <td className="p-4 text-sm">{profile.city}</td>
                      <td className="p-4 text-sm text-[#8a8a8a]">{profile.submitted}</td>
                      <td className="p-4">
                        <div className="flex gap-2">
                          <button className="p-1.5 hover:bg-green-50 transition-colors" title="Approve">
                            <CheckCircle className="w-4 h-4 text-green-600" />
                          </button>
                          <button className="p-1.5 hover:bg-red-50 transition-colors" title="Reject">
                            <XCircle className="w-4 h-4 text-red-600" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'inquiries' && (
          <div className="border border-[#e6e6e2]">
            <div className="p-4 border-b border-[#e6e6e2]">
              <h3 className="text-lg font-['Playfair_Display']">Contact Inquiries</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#e6e6e2]">
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Name</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Email</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Subject</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Status</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {inquiries.map((inquiry) => (
                    <tr key={inquiry.id} className="border-b border-[#e6e6e2] hover:bg-[#fcfbfa]">
                      <td className="p-4 text-sm">{inquiry.name}</td>
                      <td className="p-4 text-sm text-[#8a8a8a]">{inquiry.email}</td>
                      <td className="p-4 text-sm">{inquiry.subject}</td>
                      <td className="p-4">
                        <span className={`text-xs uppercase tracking-wider px-2 py-1 ${
                          inquiry.status === 'new' ? 'bg-[#020202] text-[#fcfbfa]' :
                          inquiry.status === 'read' ? 'bg-[#e6e6e2] text-[#8a8a8a]' :
                          'bg-green-100 text-green-800'
                        }`}>
                          {inquiry.status}
                        </span>
                      </td>
                      <td className="p-4 text-sm text-[#8a8a8a]">{inquiry.date}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="border border-[#e6e6e2]">
            <div className="p-4 border-b border-[#e6e6e2]">
              <h3 className="text-lg font-['Playfair_Display']">All Users</h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="border-b border-[#e6e6e2]">
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">ID</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Name</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Email</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Category</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Plan</th>
                    <th className="text-left p-4 text-xs uppercase tracking-wider text-[#8a8a8a] font-normal">Joined</th>
                  </tr>
                </thead>
                <tbody>
                  {[
                    { id: 1, name: 'Rahul Sharma', email: 'rahul@email.com', category: 'regular', plan: 'gold', joined: '2026-05-15' },
                    { id: 2, name: 'Priya Patel', email: 'priya@email.com', category: 'regular', plan: 'silver', joined: '2026-05-20' },
                    { id: 3, name: 'Lakhan Patel', email: 'lakhan@email.com', category: 'farmer', plan: 'free', joined: '2026-06-01' },
                    { id: 4, name: 'Ananya Gupta', email: 'ananya@email.com', category: 'regular', plan: 'platinum', joined: '2026-06-05' },
                  ].map((user) => (
                    <tr key={user.id} className="border-b border-[#e6e6e2] hover:bg-[#fcfbfa]">
                      <td className="p-4 text-sm text-[#8a8a8a]">#{user.id}</td>
                      <td className="p-4 text-sm">{user.name}</td>
                      <td className="p-4 text-sm text-[#8a8a8a]">{user.email}</td>
                      <td className="p-4">
                        <span className="text-xs uppercase tracking-wider px-2 py-1 bg-[#e6e6e2]">{user.category}</span>
                      </td>
                      <td className="p-4">
                        <span className="text-xs uppercase tracking-wider px-2 py-1 bg-[#020202] text-[#fcfbfa]">{user.plan}</span>
                      </td>
                      <td className="p-4 text-sm text-[#8a8a8a]">{user.joined}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
