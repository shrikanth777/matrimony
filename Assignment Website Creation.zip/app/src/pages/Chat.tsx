import { useState, useRef, useEffect } from 'react';
import { Link, useParams } from 'react-router';
import { ArrowLeft, Send, Phone, Video } from 'lucide-react';

interface Message {
  id: number;
  sender: 'me' | 'them';
  text: string;
  time: string;
}

const mockMessages: Message[] = [
  { id: 1, sender: 'them', text: 'Hi! Thanks for accepting my interest. I was really impressed by your profile.', time: '10:30 AM' },
  { id: 2, sender: 'me', text: 'Hello! Thank you, I liked your profile too. Tell me more about yourself.', time: '10:32 AM' },
  { id: 3, sender: 'them', text: 'I work as a software engineer in Bangalore. I enjoy reading and traveling on weekends.', time: '10:35 AM' },
  { id: 4, sender: 'me', text: 'That sounds great! I love traveling too. Which places have you visited recently?', time: '10:38 AM' },
  { id: 5, sender: 'them', text: 'I recently went to Kerala and it was absolutely beautiful. The backwaters were mesmerizing.', time: '10:42 AM' },
];

export default function Chat() {
  useParams<{ interestId: string }>();
  const [messages, setMessages] = useState<Message[]>(mockMessages);
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    const newMessage: Message = {
      id: messages.length + 1,
      sender: 'me',
      text: input,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages([...messages, newMessage]);
    setInput('');
  };

  return (
    <div className="min-h-screen bg-[#f4f2ec] flex flex-col">
      {/* Header */}
      <div className="border-b border-[#e6e6e2] bg-[#fcfbfa]">
        <div className="max-w-4xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link to="/matches" className="text-[#8a8a8a] hover:text-[#020202]">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <div className="w-10 h-10 rounded-full bg-[#e6e6e2] flex items-center justify-center font-['Playfair_Display']">
              P
            </div>
            <div>
              <h3 className="text-sm font-medium">Priya Patel</h3>
              <p className="text-xs text-green-600">Online</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <button className="p-2 hover:bg-[#e6e6e2] rounded-full transition-colors">
              <Phone className="w-4 h-4" />
            </button>
            <button className="p-2 hover:bg-[#e6e6e2] rounded-full transition-colors">
              <Video className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-4 py-6 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'me' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[70%] px-4 py-3 ${
                  msg.sender === 'me'
                    ? 'bg-[#020202] text-[#fcfbfa]'
                    : 'bg-[#fcfbfa] border border-[#e6e6e2]'
                }`}
              >
                <p className="text-sm leading-relaxed">{msg.text}</p>
                <p className={`text-xs mt-1 ${msg.sender === 'me' ? 'text-[#8a8a8a]' : 'text-[#8a8a8a]'}`}>
                  {msg.time}
                </p>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Input */}
      <div className="border-t border-[#e6e6e2] bg-[#fcfbfa]">
        <form onSubmit={handleSend} className="max-w-4xl mx-auto px-4 py-3 flex items-center gap-3">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            className="p-3 bg-[#020202] text-[#fcfbfa] hover:bg-[#333] transition-colors disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
