import { Link } from 'react-router';
import { Heart, HeartHandshake, MessageCircle, Bell, Settings, Crown, ChevronRight, MapPin, Briefcase, GraduationCap } from 'lucide-react';

export default function Dashboard() {
  return (
    <div className="min-h-screen bg-[#f4f2ec]">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Link to="/" className="flex items-center gap-2">
            <Heart className="w-5 h-5" />
            <span className="font-['Playfair_Display'] text-lg">AVMatrimony</span>
          </Link>
          <div className="flex items-center gap-4">
            <Link to="/matches" className="relative">
              <HeartHandshake className="w-5 h-5 text-[#020202]" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#020202] text-[#fcfbfa] text-[10px] rounded-full flex items-center justify-center">3</span>
            </Link>
            <Link to="/chat/1" className="relative">
              <MessageCircle className="w-5 h-5 text-[#020202]" />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#020202] text-[#fcfbfa] text-[10px] rounded-full flex items-center justify-center">5</span>
            </Link>
            <button className="relative">
              <Bell className="w-5 h-5 text-[#020202]" />
            </button>
            <Link to="/subscription">
              <Crown className="w-5 h-5 text-[#020202]" />
            </Link>
            <Settings className="w-5 h-5 text-[#020202] cursor-pointer" />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Sidebar - Profile Summary */}
          <div className="lg:col-span-1">
            <div className="border border-[#e6e6e2] p-6 mb-6">
              <div className="flex flex-col items-center text-center">
                <div className="w-24 h-24 rounded-full bg-[#e6e6e2] flex items-center justify-center text-3xl font-['Playfair_Display'] mb-4">
                  R
                </div>
                <h2 className="text-xl font-['Playfair_Display'] mb-1">Rahul Sharma</h2>
                <p className="text-sm text-[#8a8a8a] mb-2">AVM123456</p>
                <span className="px-3 py-1 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-wider mb-4">Free Plan</span>
                <div className="w-full space-y-2 text-left">
                  <div className="flex items-center gap-2 text-sm text-[#8a8a8a]">
                    <Briefcase className="w-4 h-4" />
                    Software Engineer
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#8a8a8a]">
                    <GraduationCap className="w-4 h-4" />
                    B.Tech, IIT Delhi
                  </div>
                  <div className="flex items-center gap-2 text-sm text-[#8a8a8a]">
                    <MapPin className="w-4 h-4" />
                    Bangalore, Karnataka
                  </div>
                </div>
                <Link
                  to="/profile-setup"
                  className="mt-4 w-full py-2 border border-[#020202] text-xs uppercase tracking-[0.1em] text-center hover:bg-[#020202] hover:text-[#fcfbfa] transition-colors"
                >
                  Edit Profile
                </Link>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="border border-[#e6e6e2] p-6">
              <h3 className="text-xs uppercase tracking-[0.1em] mb-4">Activity</h3>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#8a8a8a]">Profile Views</span>
                  <span className="text-sm font-medium">124</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#8a8a8a]">Interests Sent</span>
                  <span className="text-sm font-medium">8</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#8a8a8a]">Interests Received</span>
                  <span className="text-sm font-medium">12</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-[#8a8a8a]">Mutual Matches</span>
                  <span className="text-sm font-medium">3</span>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* AI Match Suggestions */}
            <div className="border border-[#e6e6e2] p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-['Playfair_Display']">AI Match Suggestions</h3>
                <Link to="/search" className="text-xs uppercase tracking-[0.1em] text-[#8a8a8a] hover:text-[#020202] flex items-center gap-1">
                  View All <ChevronRight className="w-4 h-4" />
                </Link>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {[
                  { name: 'Priya Patel', age: 26, match: 92, profession: 'Doctor', location: 'Ahmedabad' },
                  { name: 'Sneha Gupta', age: 27, match: 88, profession: 'Data Scientist', location: 'Hyderabad' },
                  { name: 'Ananya Sharma', age: 25, match: 85, profession: 'Marketing Manager', location: 'Mumbai' },
                  { name: 'Meera Iyer', age: 28, match: 82, profession: 'Architect', location: 'Chennai' },
                ].map((match, i) => (
                  <div key={i} className="flex items-center gap-4 p-4 border border-[#e6e6e2] hover:border-[#020202] transition-colors">
                    <div className="w-12 h-12 rounded-full bg-[#e6e6e2] flex items-center justify-center font-['Playfair_Display']">
                      {match.name.charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-medium truncate">{match.name}</h4>
                      <p className="text-xs text-[#8a8a8a]">{match.age} yrs | {match.profession}</p>
                      <p className="text-xs text-[#8a8a8a]">{match.location}</p>
                    </div>
                    <div className="text-center">
                      <span className="block text-lg font-['Playfair_Display']">{match.match}%</span>
                      <span className="text-[10px] uppercase tracking-wider text-[#8a8a8a]">Match</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Recent Interests */}
            <div className="border border-[#e6e6e2] p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-['Playfair_Display']">Recent Interests</h3>
                <Link to="/matches" className="text-xs uppercase tracking-[0.1em] text-[#8a8a8a] hover:text-[#020202] flex items-center gap-1">
                  View All <ChevronRight className="w-4 h-4" />
                </Link>
              </div>

              <div className="space-y-3">
                {[
                  { name: 'Ananya Sharma', status: 'pending', time: '2 hours ago', type: 'sent' },
                  { name: 'Vikram Singh', status: 'accepted', time: '1 day ago', type: 'received' },
                  { name: 'Priya Patel', status: 'pending', time: '3 days ago', type: 'sent' },
                ].map((interest, i) => (
                  <div key={i} className="flex items-center justify-between p-3 border border-[#e6e6e2]">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#e6e6e2] flex items-center justify-center text-sm font-['Playfair_Display']">
                        {interest.name.charAt(0)}
                      </div>
                      <div>
                        <p className="text-sm font-medium">{interest.name}</p>
                        <p className="text-xs text-[#8a8a8a]">{interest.time}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`text-xs uppercase tracking-wider px-2 py-1 ${
                        interest.status === 'accepted' ? 'bg-[#020202] text-[#fcfbfa]' :
                        interest.status === 'rejected' ? 'bg-red-100 text-red-800' :
                        'bg-[#e6e6e2] text-[#8a8a8a]'
                      }`}>
                        {interest.status}
                      </span>
                      <span className="text-xs text-[#8a8a8a]">{interest.type}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Upgrade Banner */}
            <div className="border border-[#020202] bg-[#020202] p-6 text-[#fcfbfa]">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-lg font-['Playfair_Display'] mb-1">Upgrade to Gold</h3>
                  <p className="text-sm text-[#e6e6e2]">Unlock unlimited interests, priority listing, and AI match suggestions</p>
                </div>
                <Link
                  to="/subscription"
                  className="px-6 py-2 bg-[#fcfbfa] text-[#020202] text-xs uppercase tracking-[0.1em] hover:bg-[#e6e6e2] transition-colors flex-shrink-0"
                >
                  Upgrade
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
