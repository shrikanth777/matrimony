import Navigation from '@/components/ui-custom/Navigation';
import HeroSection from '@/sections/HeroSection';
import CurvedTextSection from '@/sections/CurvedTextSection';
import FeaturesSection from '@/sections/FeaturesSection';
import SuccessStoriesSection from '@/sections/SuccessStoriesSection';
import PlansSection from '@/sections/PlansSection';
import ContactSection from '@/sections/ContactSection';
import Footer from '@/sections/Footer';

export default function Home() {
  return (
    <div className="min-h-screen bg-[#f4f2ec]">
      <Navigation />
      <HeroSection />
      <CurvedTextSection />
      <FeaturesSection />
      <SuccessStoriesSection />
      <PlansSection />
      <ContactSection />
      <Footer />
    </div>
  );
}
