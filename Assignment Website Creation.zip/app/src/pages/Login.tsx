import { useState } from 'react';
import { Link } from 'react-router';
import { Heart, Eye, EyeOff } from 'lucide-react';

export default function Login() {
  const [showPassword, setShowPassword] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Login logic would go here
    window.location.href = '/dashboard';
  };

  return (
    <div className="min-h-screen bg-[#f4f2ec] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <Heart className="w-5 h-5" />
            <span className="font-['Playfair_Display'] text-xl">AVMatrimony</span>
          </Link>
          <h1 className="text-3xl font-['Playfair_Display'] mb-2">Welcome Back</h1>
          <p className="text-[#8a8a8a] text-sm">Sign in to continue your journey</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="email"
            placeholder="Email Address"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
            required
          />

          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              placeholder="Password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors pr-12"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-[#8a8a8a] hover:text-[#020202]"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>

          <div className="flex justify-between items-center">
            <label className="flex items-center gap-2 text-sm text-[#8a8a8a] cursor-pointer">
              <input type="checkbox" className="border-[#e6e6e2]" />
              Remember me
            </label>
            <span className="text-sm text-[#8a8a8a] hover:text-[#020202] cursor-pointer transition-colors">
              Forgot password?
            </span>
          </div>

          <button
            type="submit"
            className="w-full py-3 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-[0.1em] hover:bg-[#333] transition-colors"
          >
            Sign In
          </button>

          <div className="relative my-6">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-[#e6e6e2]" />
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-4 bg-[#f4f2ec] text-[#8a8a8a]">or</span>
            </div>
          </div>

          <button
            type="button"
            className="w-full py-3 border border-[#e6e6e2] text-xs uppercase tracking-[0.1em] hover:border-[#020202] transition-colors"
          >
            Continue with Google
          </button>

          <div className="text-center mt-6">
            <Link to="/register" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">
              Do not have an account? Get Started
            </Link>
          </div>
        </form>
      </div>
    </div>
  );
}
