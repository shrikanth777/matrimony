import { useState } from 'react';
import { Link } from 'react-router';
import { Heart, CheckCircle, XCircle, Clock, MessageCircle, ArrowRight } from 'lucide-react';

type InterestStatus = 'pending' | 'accepted' | 'rejected';

interface Interest {
  id: number;
  name: string;
  age: number;
  profession: string;
  location: string;
  status: InterestStatus;
  type: 'sent' | 'received';
  message?: string;
}

const mockInterests: Interest[] = [
  { id: 1, name: 'Priya Patel', age: 26, profession: 'Doctor', location: 'Ahmedabad', status: 'pending', type: 'sent', message: 'Hi, I liked your profile. Would love to connect!' },
  { id: 2, name: 'Vikram Singh', age: 30, profession: 'CA', location: 'Delhi', status: 'accepted', type: 'received', message: 'Would like to know more about you.' },
  { id: 3, name: 'Ananya Sharma', age: 25, profession: 'Marketing Manager', location: 'Mumbai', status: 'pending', type: 'received' },
  { id: 4, name: 'Sneha Gupta', age: 27, profession: 'Data Scientist', location: 'Hyderabad', status: 'accepted', type: 'sent' },
  { id: 5, name: 'Meera Iyer', age: 28, profession: 'Architect', location: 'Chennai', status: 'rejected', type: 'sent' },
];

export default function Matches() {
  const [filter, setFilter] = useState<'all' | 'sent' | 'received' | 'accepted'>('all');

  const filtered = mockInterests.filter((i) => {
    if (filter === 'all') return true;
    if (filter === 'sent') return i.type === 'sent';
    if (filter === 'received') return i.type === 'received';
    if (filter === 'accepted') return i.status === 'accepted';
    return true;
  });

  return (
    <div className="min-h-screen bg-[#f4f2ec]">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <Link to="/" className="flex items-center gap-2">
            <Heart className="w-5 h-5" />
            <span className="font-['Playfair_Display'] text-lg">AVMatrimony</span>
          </Link>
          <Link to="/dashboard" className="text-sm text-[#8a8a8a] hover:text-[#020202]">Dashboard</Link>
        </div>

        <h1 className="text-3xl font-['Playfair_Display'] mb-2">My Interests</h1>
        <p className="text-[#8a8a8a] text-sm mb-6">Manage your sent and received interests</p>

        {/* Filter Tabs */}
        <div className="flex gap-2 mb-6 overflow-x-auto">
          {(['all', 'sent', 'received', 'accepted'] as const).map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`px-4 py-2 text-xs uppercase tracking-[0.1em] border transition-colors whitespace-nowrap ${
                filter === f ? 'bg-[#020202] text-[#fcfbfa] border-[#020202]' : 'border-[#e6e6e2] hover:border-[#020202]'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {filtered.map((interest) => (
            <div key={interest.id} className="border border-[#e6e6e2] p-6 hover:border-[#020202] transition-colors">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-full bg-[#e6e6e2] flex items-center justify-center text-lg font-['Playfair_Display']">
                    {interest.name.charAt(0)}
                  </div>
                  <div>
                    <h3 className="text-lg font-['Playfair_Display']">{interest.name}</h3>
                    <p className="text-sm text-[#8a8a8a]">{interest.age} yrs | {interest.profession} | {interest.location}</p>
                    {interest.message && (
                      <p className="text-sm text-[#8a8a8a] mt-1 italic">"{interest.message}"</p>
                    )}
                    <div className="flex items-center gap-2 mt-2">
                      <span className={`text-xs uppercase tracking-wider px-2 py-0.5 ${
                        interest.status === 'accepted' ? 'bg-[#020202] text-[#fcfbfa]' :
                        interest.status === 'rejected' ? 'bg-red-100 text-red-800' :
                        'bg-[#e6e6e2] text-[#8a8a8a]'
                      }`}>
                        {interest.status}
                      </span>
                      <span className="text-xs text-[#8a8a8a] uppercase tracking-wider">{interest.type}</span>
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {interest.type === 'received' && interest.status === 'pending' && (
                    <>
                      <button className="p-2 hover:bg-green-50 transition-colors" title="Accept">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                      </button>
                      <button className="p-2 hover:bg-red-50 transition-colors" title="Reject">
                        <XCircle className="w-5 h-5 text-red-600" />
                      </button>
                    </>
                  )}
                  {interest.status === 'accepted' && (
                    <Link to={`/chat/${interest.id}`} className="flex items-center gap-1 px-3 py-1.5 border border-[#020202] text-xs uppercase tracking-[0.1em] hover:bg-[#020202] hover:text-[#fcfbfa] transition-colors">
                      <MessageCircle className="w-3.5 h-3.5" />
                      Chat
                    </Link>
                  )}
                  {interest.status === 'pending' && interest.type === 'sent' && (
                    <Clock className="w-5 h-5 text-[#8a8a8a]" />
                  )}
                </div>
              </div>
            </div>
          ))}
        </div>

        {filtered.length === 0 && (
          <div className="text-center py-16">
            <Heart className="w-12 h-12 text-[#e6e6e2] mx-auto mb-4" />
            <h3 className="text-xl font-['Playfair_Display'] mb-2">No interests found</h3>
            <p className="text-[#8a8a8a] text-sm mb-4">Start browsing profiles and send interests</p>
            <Link to="/search" className="inline-flex items-center gap-1 text-sm text-[#020202] hover:underline">
              Browse Profiles <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
