import { Link } from 'react-router';
import { Heart, ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen bg-[#f4f2ec] flex items-center justify-center px-4">
      <div className="text-center">
        <Link to="/" className="inline-flex items-center gap-2 mb-8">
          <Heart className="w-5 h-5" />
          <span className="font-['Playfair_Display'] text-xl">AVMatrimony</span>
        </Link>
        <h1 className="text-8xl font-['Playfair_Display'] mb-4">404</h1>
        <p className="text-[#8a8a8a] text-lg mb-8">The page you are looking for does not exist.</p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-6 py-3 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-[0.1em] hover:bg-[#333] transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Home
        </Link>
      </div>
    </div>
  );
}
