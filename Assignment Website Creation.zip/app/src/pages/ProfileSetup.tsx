import { useState } from 'react';
import { useSearchParams, Link } from 'react-router';
import { Heart, ArrowLeft, Upload } from 'lucide-react';

export default function ProfileSetup() {
  const [searchParams] = useSearchParams();
  const category = searchParams.get('category') || 'regular';
  const [step, setStep] = useState(1);
  const [regularData, setRegularData] = useState({
    gender: '',
    age: '',
    religion: '',
    caste: '',
    education: '',
    profession: '',
    salaryRange: '',
    city: '',
    state: '',
    aboutMe: '',
  });
  const [farmerData, setFarmerData] = useState({
    gender: '',
    age: '',
    farmingType: '',
    landSize: '',
    annualIncome: '',
    hasTractor: false,
    hasDairyPoultry: false,
    village: '',
    district: '',
    state: '',
    aboutMe: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    window.location.href = '/dashboard';
  };

  return (
    <div className="min-h-screen bg-[#f4f2ec] px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <Link to="/register" className="flex items-center gap-1 text-sm text-[#8a8a8a] hover:text-[#020202]">
            <ArrowLeft className="w-4 h-4" />
            Back
          </Link>
          <Link to="/" className="flex items-center gap-2">
            <Heart className="w-5 h-5" />
            <span className="font-['Playfair_Display'] text-lg">AVMatrimony</span>
          </Link>
          <span className="text-xs text-[#8a8a8a]">Step {step} of 3</span>
        </div>

        <div className="mb-8">
          <div className="flex gap-2 mb-6">
            {[1, 2, 3].map((s) => (
              <div
                key={s}
                className={`h-1 flex-1 transition-colors ${
                  s <= step ? 'bg-[#020202]' : 'bg-[#e6e6e2]'
                }`}
              />
            ))}
          </div>
          <h1 className="text-3xl font-['Playfair_Display'] mb-2">
            {category === 'farmer' ? 'Farmer Profile' : 'Personal Profile'}
          </h1>
          <p className="text-[#8a8a8a] text-sm">
            {step === 1 && 'Basic Information'}
            {step === 2 && category === 'farmer' ? 'Farm Details' : 'Professional Details'}
            {step === 3 && 'Location & Photos'}
          </p>
        </div>

        <form onSubmit={handleSubmit}>
          {step === 1 && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <select
                  value={category === 'farmer' ? farmerData.gender : regularData.gender}
                  onChange={(e) => category === 'farmer'
                    ? setFarmerData({ ...farmerData, gender: e.target.value })
                    : setRegularData({ ...regularData, gender: e.target.value })
                  }
                  className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="male">Male</option>
                  <option value="female">Female</option>
                  <option value="other">Other</option>
                </select>
                <input
                  type="number"
                  placeholder="Age"
                  min={18}
                  max={80}
                  value={category === 'farmer' ? farmerData.age : regularData.age}
                  onChange={(e) => category === 'farmer'
                    ? setFarmerData({ ...farmerData, age: e.target.value })
                    : setRegularData({ ...regularData, age: e.target.value })
                  }
                  className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  required
                />
              </div>

              {category === 'regular' ? (
                <>
                  <input
                    type="text"
                    placeholder="Religion"
                    value={regularData.religion}
                    onChange={(e) => setRegularData({ ...regularData, religion: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  />
                  <input
                    type="text"
                    placeholder="Caste"
                    value={regularData.caste}
                    onChange={(e) => setRegularData({ ...regularData, caste: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  />
                </>
              ) : (
                <input
                  type="text"
                  placeholder="Farming Type (e.g., Organic, Dairy, Crop)"
                  value={farmerData.farmingType}
                  onChange={(e) => setFarmerData({ ...farmerData, farmingType: e.target.value })}
                  className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  required
                />
              )}

              <button
                type="button"
                onClick={() => setStep(2)}
                className="w-full py-3 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-[0.1em] hover:bg-[#333] transition-colors"
              >
                Continue
              </button>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-4">
              {category === 'regular' ? (
                <>
                  <input
                    type="text"
                    placeholder="Education Level"
                    value={regularData.education}
                    onChange={(e) => setRegularData({ ...regularData, education: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  />
                  <input
                    type="text"
                    placeholder="Profession"
                    value={regularData.profession}
                    onChange={(e) => setRegularData({ ...regularData, profession: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  />
                  <select
                    value={regularData.salaryRange}
                    onChange={(e) => setRegularData({ ...regularData, salaryRange: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  >
                    <option value="">Select Salary Range</option>
                    <option value="Below 3 LPA">Below 3 LPA</option>
                    <option value="3-6 LPA">3-6 LPA</option>
                    <option value="6-10 LPA">6-10 LPA</option>
                    <option value="10-15 LPA">10-15 LPA</option>
                    <option value="15-25 LPA">15-25 LPA</option>
                    <option value="Above 25 LPA">Above 25 LPA</option>
                  </select>
                </>
              ) : (
                <>
                  <input
                    type="text"
                    placeholder="Land Size (in Acres)"
                    value={farmerData.landSize}
                    onChange={(e) => setFarmerData({ ...farmerData, landSize: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  />
                  <select
                    value={farmerData.annualIncome}
                    onChange={(e) => setFarmerData({ ...farmerData, annualIncome: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  >
                    <option value="">Select Annual Income</option>
                    <option value="Below 2 Lakhs">Below 2 Lakhs</option>
                    <option value="2-5 Lakhs">2-5 Lakhs</option>
                    <option value="5-10 Lakhs">5-10 Lakhs</option>
                    <option value="10-20 Lakhs">10-20 Lakhs</option>
                    <option value="Above 20 Lakhs">Above 20 Lakhs</option>
                  </select>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                      <input
                        type="checkbox"
                        checked={farmerData.hasTractor}
                        onChange={(e) => setFarmerData({ ...farmerData, hasTractor: e.target.checked })}
                        className="border-[#e6e6e2]"
                      />
                      Has Tractor
                    </label>
                    <label className="flex items-center gap-2 text-sm cursor-pointer">
                      <input
                        type="checkbox"
                        checked={farmerData.hasDairyPoultry}
                        onChange={(e) => setFarmerData({ ...farmerData, hasDairyPoultry: e.target.checked })}
                        className="border-[#e6e6e2]"
                      />
                      Dairy/Poultry
                    </label>
                  </div>
                </>
              )}

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setStep(1)}
                  className="flex-1 py-3 border border-[#e6e6e2] text-xs uppercase tracking-[0.1em] hover:border-[#020202] transition-colors"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={() => setStep(3)}
                  className="flex-1 py-3 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-[0.1em] hover:bg-[#333] transition-colors"
                >
                  Continue
                </button>
              </div>
            </div>
          )}

          {step === 3 && (
            <div className="space-y-4">
              {category === 'farmer' ? (
                <>
                  <input
                    type="text"
                    placeholder="Village"
                    value={farmerData.village}
                    onChange={(e) => setFarmerData({ ...farmerData, village: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  />
                  <input
                    type="text"
                    placeholder="District"
                    value={farmerData.district}
                    onChange={(e) => setFarmerData({ ...farmerData, district: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                  />
                </>
              ) : (
                <input
                  type="text"
                  placeholder="City"
                  value={regularData.city}
                  onChange={(e) => setRegularData({ ...regularData, city: e.target.value })}
                  className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                />
              )}
              <input
                type="text"
                placeholder="State"
                value={category === 'farmer' ? farmerData.state : regularData.state}
                onChange={(e) => category === 'farmer'
                  ? setFarmerData({ ...farmerData, state: e.target.value })
                  : setRegularData({ ...regularData, state: e.target.value })
                }
                className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
              />
              <textarea
                placeholder="About Me"
                value={category === 'farmer' ? farmerData.aboutMe : regularData.aboutMe}
                onChange={(e) => category === 'farmer'
                  ? setFarmerData({ ...farmerData, aboutMe: e.target.value })
                  : setRegularData({ ...regularData, aboutMe: e.target.value })
                }
                rows={3}
                className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none resize-none"
              />

              <div className="border border-dashed border-[#e6e6e2] p-8 text-center hover:border-[#020202] transition-colors cursor-pointer">
                <Upload className="w-6 h-6 mx-auto mb-2 text-[#8a8a8a]" />
                <p className="text-sm text-[#8a8a8a]">Upload Profile Photos</p>
                <p className="text-xs text-[#8a8a8a] mt-1">Click or drag photos here</p>
              </div>

              <div className="flex gap-4">
                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="flex-1 py-3 border border-[#e6e6e2] text-xs uppercase tracking-[0.1em] hover:border-[#020202] transition-colors"
                >
                  Back
                </button>
                <button
                  type="submit"
                  className="flex-1 py-3 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-[0.1em] hover:bg-[#333] transition-colors"
                >
                  Complete Profile
                </button>
              </div>
            </div>
          )}
        </form>
      </div>
    </div>
  );
}
