import { useState } from 'react';
import { Link } from 'react-router';
import { Heart, ArrowLeft, User, Tractor } from 'lucide-react';

export default function Register() {
  const [step, setStep] = useState<'category' | 'form'>('category');
  const [category, setCategory] = useState<'regular' | 'farmer'>('regular');
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    password: '',
    confirmPassword: '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Registration would go here - redirect to profile setup
    window.location.href = '/profile-setup?category=' + category;
  };

  return (
    <div className="min-h-screen bg-[#f4f2ec] flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <Link to="/" className="inline-flex items-center gap-2 mb-6">
            <Heart className="w-5 h-5" />
            <span className="font-['Playfair_Display'] text-xl">AVMatrimony</span>
          </Link>
          <h1 className="text-3xl font-['Playfair_Display'] mb-2">
            {step === 'category' ? 'Choose Your Path' : 'Create Account'}
          </h1>
          <p className="text-[#8a8a8a] text-sm">
            {step === 'category'
              ? 'Select the matrimony category that fits you'
              : 'Fill in your details to get started'}
          </p>
        </div>

        {step === 'category' ? (
          <div className="space-y-4">
            <button
              onClick={() => { setCategory('regular'); setStep('form'); }}
              className={`w-full p-6 border text-left transition-all duration-300 ${
                category === 'regular'
                  ? 'border-[#020202] bg-[#020202] text-[#fcfbfa]'
                  : 'border-[#e6e6e2] hover:border-[#020202]'
              }`}
            >
              <User className={`w-8 h-8 mb-3 ${category === 'regular' ? 'text-[#fcfbfa]' : 'text-[#020202]'}`} />
              <h3 className="text-lg font-['Playfair_Display'] mb-1">Regular Matrimony</h3>
              <p className={`text-sm ${category === 'regular' ? 'text-[#e6e6e2]' : 'text-[#8a8a8a]'}`}>
                Find matches based on education, profession, religion, and lifestyle preferences
              </p>
            </button>

            <button
              onClick={() => { setCategory('farmer'); setStep('form'); }}
              className={`w-full p-6 border text-left transition-all duration-300 ${
                category === 'farmer'
                  ? 'border-[#020202] bg-[#020202] text-[#fcfbfa]'
                  : 'border-[#e6e6e2] hover:border-[#020202]'
              }`}
            >
              <Tractor className={`w-8 h-8 mb-3 ${category === 'farmer' ? 'text-[#fcfbfa]' : 'text-[#020202]'}`} />
              <h3 className="text-lg font-['Playfair_Display'] mb-1">Farmer Matrimony</h3>
              <p className={`text-sm ${category === 'farmer' ? 'text-[#e6e6e2]' : 'text-[#8a8a8a]'}`}>
                Connect with partners who understand and share rural and agricultural values
              </p>
            </button>

            <div className="text-center mt-6">
              <Link to="/login" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">
                Already have an account? Login
              </Link>
            </div>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <button
              type="button"
              onClick={() => setStep('category')}
              className="flex items-center gap-1 text-sm text-[#8a8a8a] hover:text-[#020202] mb-4"
            >
              <ArrowLeft className="w-4 h-4" />
              Back
            </button>

            <input
              type="text"
              placeholder="Full Name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
              required
            />
            <input
              type="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={(e) => setFormData({ ...formData, email: e.target.value })}
              className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
              required
            />
            <input
              type="tel"
              placeholder="Phone Number"
              value={formData.phone}
              onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
              className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
              required
            />
            <input
              type="password"
              placeholder="Password"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
              required
            />
            <input
              type="password"
              placeholder="Confirm Password"
              value={formData.confirmPassword}
              onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
              className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
              required
            />

            <button
              type="submit"
              className="w-full py-3 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-[0.1em] hover:bg-[#333] transition-colors"
            >
              Continue to Profile Setup
            </button>

            <div className="text-center">
              <Link to="/login" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">
                Already have an account? Login
              </Link>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
