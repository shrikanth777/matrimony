import { useState } from 'react';
import { Link, useSearchParams } from 'react-router';
import { Heart, Search as SearchIcon, Filter, MapPin, Briefcase, GraduationCap, Send } from 'lucide-react';

const mockProfiles = [
  { id: 1, name: 'Ananya Sharma', age: 26, gender: 'female', religion: 'Hindu', caste: 'Brahmin', education: 'MBA', profession: 'Marketing Manager', city: 'Mumbai', state: 'Maharashtra', aboutMe: 'Ambitious and family-oriented professional looking for a like-minded partner.' },
  { id: 2, name: 'Rahul Verma', age: 29, gender: 'male', religion: 'Hindu', caste: 'Rajput', education: 'B.Tech', profession: 'Software Engineer', city: 'Bangalore', state: 'Karnataka', aboutMe: 'Tech enthusiast who values tradition and modern thinking equally.' },
  { id: 3, name: 'Priya Patel', age: 24, gender: 'female', religion: 'Hindu', caste: 'Patel', education: 'MBBS', profession: 'Doctor', city: 'Ahmedabad', state: 'Gujarat', aboutMe: 'Compassionate doctor seeking a partner who understands the medical profession.' },
  { id: 4, name: 'Vikram Singh', age: 30, gender: 'male', religion: 'Hindu', caste: 'Thakur', education: 'CA', profession: 'Chartered Accountant', city: 'Delhi', state: 'Delhi', aboutMe: 'Financially stable and looking for a partner to build a life together.' },
  { id: 5, name: 'Sneha Gupta', age: 27, gender: 'female', religion: 'Hindu', caste: 'Agarwal', education: 'M.Tech', profession: 'Data Scientist', city: 'Hyderabad', state: 'Telangana', aboutMe: 'Data scientist with a love for classical music and travel.' },
  { id: 6, name: 'Arjun Reddy', age: 28, gender: 'male', religion: 'Hindu', caste: 'Reddy', education: 'MBA', profession: 'Business Analyst', city: 'Chennai', state: 'Tamil Nadu', aboutMe: 'Balancing career ambitions with family values.' },
];

const mockFarmers = [
  { id: 1, name: 'Lakhan Patel', age: 28, gender: 'male', farmingType: 'Organic Farming', landSize: '15 Acres', village: 'Rampur', district: 'Mehsana', state: 'Gujarat', aboutMe: 'Third-generation farmer passionate about organic practices.' },
  { id: 2, name: 'Gita Devi', age: 25, gender: 'female', farmingType: 'Dairy Farming', landSize: '8 Acres', village: 'Khetpur', district: 'Amritsar', state: 'Punjab', aboutMe: 'Managing family dairy business, looking for a supportive partner.' },
  { id: 3, name: 'Ramesh Yadav', age: 30, gender: 'male', farmingType: 'Rice Cultivation', landSize: '25 Acres', village: 'Naya Gaon', district: 'Patna', state: 'Bihar', aboutMe: 'Progressive farmer using modern agricultural techniques.' },
  { id: 4, name: 'Sunita Kumari', age: 23, gender: 'female', farmingType: 'Horticulture', landSize: '12 Acres', village: 'Phaloda', district: 'Nashik', state: 'Maharashtra', aboutMe: 'Running a successful fruit orchard business.' },
];

export default function Search() {
  const [searchParams] = useSearchParams();
  const initialCategory = searchParams.get('category') || 'regular';
  const [category, setCategory] = useState<'regular' | 'farmer'>(initialCategory as 'regular' | 'farmer');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState({
    gender: '',
    minAge: '',
    maxAge: '',
    religion: '',
    state: '',
    farmingType: '',
  });

  const profiles = category === 'regular' ? mockProfiles : mockFarmers;

  const filteredProfiles = profiles.filter((p) => {
    if (filters.gender && p.gender !== filters.gender) return false;
    if (filters.minAge && p.age < Number(filters.minAge)) return false;
    if (filters.maxAge && p.age > Number(filters.maxAge)) return false;
    if (filters.state && !p.state?.toLowerCase().includes(filters.state.toLowerCase())) return false;
    if (category === 'regular' && filters.religion && !('religion' in p && p.religion?.toLowerCase().includes(filters.religion.toLowerCase()))) return false;
    if (category === 'farmer' && filters.farmingType && !('farmingType' in p && p.farmingType?.toLowerCase().includes(filters.farmingType.toLowerCase()))) return false;
    return true;
  });

  return (
    <div className="min-h-screen bg-[#f4f2ec]">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <Link to="/" className="flex items-center gap-2">
            <Heart className="w-5 h-5" />
            <span className="font-['Playfair_Display'] text-lg">AVMatrimony</span>
          </Link>
          <Link to="/dashboard" className="text-sm text-[#8a8a8a] hover:text-[#020202]">Dashboard</Link>
        </div>

        {/* Category Toggle */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setCategory('regular')}
            className={`px-6 py-2 text-xs uppercase tracking-[0.1em] border transition-colors ${
              category === 'regular' ? 'bg-[#020202] text-[#fcfbfa] border-[#020202]' : 'border-[#e6e6e2] hover:border-[#020202]'
            }`}
          >
            Regular Matrimony
          </button>
          <button
            onClick={() => setCategory('farmer')}
            className={`px-6 py-2 text-xs uppercase tracking-[0.1em] border transition-colors ${
              category === 'farmer' ? 'bg-[#020202] text-[#fcfbfa] border-[#020202]' : 'border-[#e6e6e2] hover:border-[#020202]'
            }`}
          >
            Farmer Matrimony
          </button>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="ml-auto flex items-center gap-2 px-4 py-2 border border-[#e6e6e2] text-xs uppercase tracking-[0.1em] hover:border-[#020202] transition-colors"
          >
            <Filter className="w-4 h-4" />
            Filters
          </button>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="p-6 border border-[#e6e6e2] mb-6 grid grid-cols-2 md:grid-cols-4 gap-4">
            <select
              value={filters.gender}
              onChange={(e) => setFilters({ ...filters, gender: e.target.value })}
              className="w-full px-3 py-2 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
            >
              <option value="">All Genders</option>
              <option value="male">Male</option>
              <option value="female">Female</option>
            </select>
            <input
              type="number"
              placeholder="Min Age"
              value={filters.minAge}
              onChange={(e) => setFilters({ ...filters, minAge: e.target.value })}
              className="w-full px-3 py-2 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
            />
            <input
              type="number"
              placeholder="Max Age"
              value={filters.maxAge}
              onChange={(e) => setFilters({ ...filters, maxAge: e.target.value })}
              className="w-full px-3 py-2 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
            />
            <input
              type="text"
              placeholder="State"
              value={filters.state}
              onChange={(e) => setFilters({ ...filters, state: e.target.value })}
              className="w-full px-3 py-2 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
            />
            {category === 'regular' ? (
              <input
                type="text"
                placeholder="Religion"
                value={filters.religion}
                onChange={(e) => setFilters({ ...filters, religion: e.target.value })}
                className="w-full px-3 py-2 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
              />
            ) : (
              <input
                type="text"
                placeholder="Farming Type"
                value={filters.farmingType}
                onChange={(e) => setFilters({ ...filters, farmingType: e.target.value })}
                className="w-full px-3 py-2 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
              />
            )}
          </div>
        )}

        {/* Results Count */}
        <p className="text-sm text-[#8a8a8a] mb-6">
          Found {filteredProfiles.length} {category === 'farmer' ? 'farmer' : ''} profiles
        </p>

        {/* Profiles Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProfiles.map((profile) => (
            <div key={profile.id} className="border border-[#e6e6e2] hover:border-[#020202] transition-all duration-300 group">
              <div className="p-6">
                <div className="flex items-start justify-between mb-4">
                  <div className="w-16 h-16 rounded-full bg-[#e6e6e2] flex items-center justify-center text-xl font-['Playfair_Display']">
                    {profile.name.charAt(0)}
                  </div>
                  <span className="text-xs uppercase tracking-[0.1em] text-[#8a8a8a]">{profile.age} yrs</span>
                </div>

                <h3 className="text-lg font-['Playfair_Display'] mb-1">{profile.name}</h3>

                {category === 'regular' ? (
                  <>
                    {'profession' in profile && (
                      <div className="flex items-center gap-2 text-sm text-[#8a8a8a] mb-1">
                        <Briefcase className="w-3.5 h-3.5" />
                        {profile.profession}
                      </div>
                    )}
                    {'education' in profile && (
                      <div className="flex items-center gap-2 text-sm text-[#8a8a8a] mb-1">
                        <GraduationCap className="w-3.5 h-3.5" />
                        {profile.education}
                      </div>
                    )}
                    {'religion' in profile && (
                      <div className="flex items-center gap-2 text-sm text-[#8a8a8a] mb-1">
                        <span className="text-xs uppercase tracking-wider">{profile.religion} {'caste' in profile ? ` - ${profile.caste}` : ''}</span>
                      </div>
                    )}
                  </>
                ) : (
                  <>
                    {'farmingType' in profile && (
                      <div className="flex items-center gap-2 text-sm text-[#8a8a8a] mb-1">
                        <span className="text-xs uppercase tracking-wider">{profile.farmingType}</span>
                      </div>
                    )}
                    {'landSize' in profile && (
                      <div className="flex items-center gap-2 text-sm text-[#8a8a8a] mb-1">
                        <MapPin className="w-3.5 h-3.5" />
                        {profile.landSize}
                      </div>
                    )}
                  </>
                )}

                <div className="flex items-center gap-2 text-sm text-[#8a8a8a] mb-3">
                  <MapPin className="w-3.5 h-3.5" />
                  {'city' in profile ? profile.city : 'village' in profile ? profile.village : ''}, {profile.state}
                </div>

                <p className="text-sm text-[#8a8a8a] leading-relaxed mb-4 line-clamp-2">
                  {profile.aboutMe}
                </p>

                <button className="flex items-center justify-center gap-2 w-full py-2 border border-[#020202] text-xs uppercase tracking-[0.1em] hover:bg-[#020202] hover:text-[#fcfbfa] transition-colors">
                  <Send className="w-3.5 h-3.5" />
                  Send Interest
                </button>
              </div>
            </div>
          ))}
        </div>

        {filteredProfiles.length === 0 && (
          <div className="text-center py-16">
            <SearchIcon className="w-12 h-12 text-[#e6e6e2] mx-auto mb-4" />
            <h3 className="text-xl font-['Playfair_Display'] mb-2">No profiles found</h3>
            <p className="text-[#8a8a8a] text-sm">Try adjusting your filters to see more results</p>
          </div>
        )}
      </div>
    </div>
  );
}
