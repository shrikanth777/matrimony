import { useState } from 'react';
import { Link } from 'react-router';
import { Heart, Check, Star, Crown, Diamond, ArrowLeft, CreditCard } from 'lucide-react';

const plans = [
  {
    id: 'free',
    name: 'Free',
    price: 0,
    duration: 'Lifetime',
    icon: Star,
    features: [
      'Create profile',
      'Browse limited matches',
      'Send 1 interest per day',
      'Basic search filters',
    ],
    cta: 'Current Plan',
    popular: false,
  },
  {
    id: 'silver',
    name: 'Silver',
    price: 999,
    duration: '3 Months',
    icon: Star,
    features: [
      'All Free features',
      'Browse unlimited matches',
      'Send 10 interests per day',
      'View contact details',
      'Priority customer support',
    ],
    cta: 'Subscribe',
    popular: false,
  },
  {
    id: 'gold',
    name: 'Gold',
    price: 1999,
    duration: '6 Months',
    icon: Crown,
    features: [
      'All Silver features',
      'Unlimited interests',
      'Priority profile listing',
      'Chat with matches',
      'AI match suggestions',
      'Read receipts',
    ],
    cta: 'Subscribe',
    popular: true,
  },
  {
    id: 'platinum',
    name: 'Platinum',
    price: 3499,
    duration: '12 Months',
    icon: Diamond,
    features: [
      'All Gold features',
      'Personal matchmaker',
      'Profile highlighting',
      'Video call support',
      'Premium badge',
      'Exclusive events access',
    ],
    cta: 'Subscribe',
    popular: false,
  },
];

export default function SubscriptionPlans() {
  const [selectedPlan, setSelectedPlan] = useState<string | null>(null);

  return (
    <div className="min-h-screen bg-[#f4f2ec]">
      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <Link to="/dashboard" className="text-[#8a8a8a] hover:text-[#020202]">
              <ArrowLeft className="w-5 h-5" />
            </Link>
            <Link to="/" className="flex items-center gap-2">
              <Heart className="w-5 h-5" />
              <span className="font-['Playfair_Display'] text-lg">AVMatrimony</span>
            </Link>
          </div>
        </div>

        <div className="text-center mb-12">
          <h1 className="text-4xl lg:text-5xl font-['Playfair_Display'] mb-4">
            Choose Your Plan
          </h1>
          <p className="text-[#8a8a8a] text-lg max-w-xl mx-auto">
            Unlock premium features to accelerate your journey to finding the perfect match
          </p>
        </div>

        {/* Plans Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {plans.map((plan) => {
            const Icon = plan.icon;
            return (
              <div
                key={plan.id}
                className={`relative p-6 lg:p-8 border transition-all duration-300 ${
                  plan.popular
                    ? 'border-[#020202] bg-[#020202] text-[#fcfbfa]'
                    : 'border-[#e6e6e2] bg-transparent hover:border-[#020202]'
                } ${selectedPlan === plan.id ? 'ring-2 ring-[#020202]' : ''}`}
                onClick={() => setSelectedPlan(plan.id)}
              >
                {plan.popular && (
                  <span className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-[#fcfbfa] text-[#020202] text-[10px] uppercase tracking-wider">
                    Most Popular
                  </span>
                )}

                <Icon className={`w-6 h-6 mb-4 ${plan.popular ? 'text-[#fcfbfa]' : 'text-[#020202]'}`} />
                <h3 className="text-xl font-['Playfair_Display'] mb-1">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-3xl font-['Playfair_Display']">
                    {plan.price === 0 ? 'Free' : `Rs. ${plan.price}`}
                  </span>
                  {plan.price > 0 && (
                    <span className={`text-xs ml-1 ${plan.popular ? 'text-[#8a8a8a]' : 'text-[#8a8a8a]'}`}>
                      / {plan.duration}
                    </span>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm">
                      <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${plan.popular ? 'text-[#fcfbfa]' : 'text-[#020202]'}`} />
                      <span className={plan.popular ? 'text-[#e6e6e2]' : 'text-[#8a8a8a]'}>{feature}</span>
                    </li>
                  ))}
                </ul>
                <button
                  className={`w-full py-3 text-xs uppercase tracking-[0.1em] transition-all duration-300 ${
                    plan.popular
                      ? 'bg-[#fcfbfa] text-[#020202] hover:bg-[#e6e6e2]'
                      : 'bg-[#020202] text-[#fcfbfa] hover:bg-[#333]'
                  }`}
                >
                  {plan.cta}
                </button>
              </div>
            );
          })}
        </div>

        {/* Payment Section */}
        {selectedPlan && selectedPlan !== 'free' && (
          <div className="max-w-md mx-auto border border-[#e6e6e2] p-8">
            <h3 className="text-lg font-['Playfair_Display'] mb-6 text-center">Payment Details</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-xs uppercase tracking-wider text-[#8a8a8a] mb-2">Selected Plan</label>
                <div className="p-3 border border-[#e6e6e2] bg-[#fcfbfa]">
                  <p className="font-medium">
                    {plans.find(p => p.id === selectedPlan)?.name} Plan
                  </p>
                  <p className="text-sm text-[#8a8a8a]">
                    Rs. {plans.find(p => p.id === selectedPlan)?.price} / {plans.find(p => p.id === selectedPlan)?.duration}
                  </p>
                </div>
              </div>
              <input
                type="text"
                placeholder="Card Number"
                className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
              />
              <div className="grid grid-cols-2 gap-4">
                <input
                  type="text"
                  placeholder="Expiry (MM/YY)"
                  className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                />
                <input
                  type="text"
                  placeholder="CVV"
                  className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
                />
              </div>
              <input
                type="text"
                placeholder="Name on Card"
                className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none"
              />
              <button className="flex items-center justify-center gap-2 w-full py-3 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-[0.1em] hover:bg-[#333] transition-colors">
                <CreditCard className="w-4 h-4" />
                Pay Rs. {plans.find(p => p.id === selectedPlan)?.price}
              </button>
            </div>
          </div>
        )}

        {/* FAQ */}
        <div className="max-w-2xl mx-auto mt-16">
          <h3 className="text-2xl font-['Playfair_Display'] text-center mb-8">Frequently Asked Questions</h3>
          <div className="space-y-4">
            {[
              { q: 'Can I upgrade or downgrade my plan?', a: 'Yes, you can upgrade or downgrade your subscription at any time. The changes will take effect immediately.' },
              { q: 'Is my payment information secure?', a: 'Absolutely. We use bank-grade encryption and comply with PCI DSS standards to protect your payment data.' },
              { q: 'Can I get a refund?', a: 'We offer a 7-day money-back guarantee if you are not satisfied with our premium features.' },
              { q: 'What happens when my subscription expires?', a: 'Your account will revert to the Free plan. You will still have access to your profile and basic features.' },
            ].map((faq, i) => (
              <div key={i} className="border border-[#e6e6e2] p-4">
                <p className="font-medium text-sm mb-2">{faq.q}</p>
                <p className="text-sm text-[#8a8a8a]">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
