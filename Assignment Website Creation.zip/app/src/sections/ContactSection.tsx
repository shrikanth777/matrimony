import { useState } from 'react';
import { trpc } from '@/providers/trpc';
import { Mail, Phone, MapPin, Send, CheckCircle } from 'lucide-react';

export default function ContactSection() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });
  const [submitted, setSubmitted] = useState(false);

  const submitMutation = trpc.contact.submit.useMutation({
    onSuccess: () => {
      setSubmitted(true);
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;
    submitMutation.mutate(formData);
  };

  return (
    <section id="contact" className="py-24 lg:py-32 px-6 lg:px-10 bg-[#fcfbfa]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 lg:mb-24">
          <h2 className="text-4xl lg:text-5xl font-['Playfair_Display'] tracking-tight mb-4">
            Get in Touch
          </h2>
          <p className="text-[#8a8a8a] text-lg max-w-xl mx-auto">
            We are here to help you on your journey to finding love
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-24">
          {/* Contact Info */}
          <div className="space-y-8">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 border border-[#e6e6e2] flex items-center justify-center flex-shrink-0">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-medium mb-1">Email Us</h4>
                <p className="text-[#8a8a8a] text-sm">support@avmatrimony.com</p>
                <p className="text-[#8a8a8a] text-sm">care@avmatrimony.com</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 border border-[#e6e6e2] flex items-center justify-center flex-shrink-0">
                <Phone className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-medium mb-1">Call Us</h4>
                <p className="text-[#8a8a8a] text-sm">+91 1800-123-4567 (Toll Free)</p>
                <p className="text-[#8a8a8a] text-sm">+91 98765-43210 (WhatsApp)</p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 border border-[#e6e6e2] flex items-center justify-center flex-shrink-0">
                <MapPin className="w-5 h-5" />
              </div>
              <div>
                <h4 className="font-medium mb-1">Visit Us</h4>
                <p className="text-[#8a8a8a] text-sm">
                  123 Tech Park, Sector 15<br />
                  Gurgaon, Haryana 122001<br />
                  India
                </p>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div>
            {submitted ? (
              <div className="flex flex-col items-center justify-center h-full text-center py-12">
                <CheckCircle className="w-12 h-12 text-[#020202] mb-4" />
                <h3 className="text-2xl font-['Playfair_Display'] mb-2">Thank You!</h3>
                <p className="text-[#8a8a8a]">We have received your message and will get back to you soon.</p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="mt-6 text-sm underline text-[#8a8a8a] hover:text-[#020202]"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="text"
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
                    required
                  />
                  <input
                    type="email"
                    placeholder="Email Address"
                    value={formData.email}
                    onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
                    required
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <input
                    type="tel"
                    placeholder="Phone Number"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
                  />
                  <input
                    type="text"
                    placeholder="Subject"
                    value={formData.subject}
                    onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                    className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors"
                  />
                </div>
                <textarea
                  placeholder="Your Message"
                  value={formData.message}
                  onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                  rows={5}
                  className="w-full px-4 py-3 border border-[#e6e6e2] bg-transparent text-sm focus:border-[#020202] focus:outline-none transition-colors resize-none"
                  required
                />
                <button
                  type="submit"
                  disabled={submitMutation.isPending}
                  className="flex items-center justify-center gap-2 w-full py-3 bg-[#020202] text-[#fcfbfa] text-xs uppercase tracking-[0.1em] hover:bg-[#333] transition-colors disabled:opacity-50"
                >
                  <Send className="w-4 h-4" />
                  {submitMutation.isPending ? 'Sending...' : 'Send Message'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
