import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

interface CurvedTextProps {
  text?: string;
  curveAmount?: number;
  duration?: number;
}

export default function CurvedTextSection({
  text = 'a union of traditions and technology, creating meaningful bonds for a lifetime.',
  curveAmount = 120,
  duration = 1.5,
}: CurvedTextProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chars = text.split('');

  useEffect(() => {
    if (!containerRef.current) return;

    const charElements = Array.from(
      containerRef.current.querySelectorAll('.char-span')
    );
    const totalChars = charElements.length;
    const viewportWidth = window.innerWidth;
    const centerIndex =
      totalChars % 2 === 0
        ? totalChars / 2 - 1
        : Math.floor(totalChars / 2);
    const minWidth = 375;
    const maxWidth = 1440;
    const clampedWidth = Math.min(Math.max(viewportWidth, minWidth), maxWidth);
    const progress = (clampedWidth - minWidth) / (maxWidth - minWidth);
    const adjustedCurve = curveAmount * (1 - progress * 0.7);

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: containerRef.current,
        start: 'top 80%',
        end: 'top 40%',
        scrub: 1,
      },
    });

    tl.fromTo(
      charElements,
      {
        y: (index: number) => {
          const dist = Math.abs(index - centerIndex);
          return dist * dist * (adjustedCurve / 25);
        },
        opacity: 0,
      },
      {
        y: 0,
        opacity: 1,
        duration: duration,
        stagger: { amount: 0.3, from: 'center' },
        ease: 'cubic-bezier(0.16, 1, 0.3, 1)',
      },
      0
    );

    return () => {
      tl.kill();
    };
  }, [text, curveAmount, duration]);

  return (
    <div ref={containerRef} className="somos-text-container">
      <div className="somos-label">Somos</div>
      <div className="curved-string">
        {chars.map((char, index) => (
          <span
            key={index}
            className="char-span"
            style={{ display: 'inline-block', willChange: 'transform' }}
          >
            {char === ' ' ? '\u00A0' : char}
          </span>
        ))}
      </div>
    </div>
  );
}
