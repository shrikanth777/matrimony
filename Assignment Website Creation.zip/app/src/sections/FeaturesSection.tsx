import { Brain, ShieldCheck, Lock, MessageCircle, Sparkles, Users } from 'lucide-react';

const features = [
  {
    icon: Brain,
    title: 'Smart AI Matching',
    description:
      'Our advanced AI engine analyzes compatibility across 50+ dimensions including personality, values, lifestyle, and preferences to find your perfect match.',
  },
  {
    icon: ShieldCheck,
    title: 'Verified Profiles',
    description:
      'Every profile undergoes multi-level verification including government ID checks, video verification, and manual review to ensure authenticity.',
  },
  {
    icon: Lock,
    title: 'Complete Privacy',
    description:
      'Your data is encrypted and protected. You control who sees your photos and contact details. No information is shared with third parties.',
  },
  {
    icon: MessageCircle,
    title: 'Real-time Chat',
    description:
      'Connect instantly with your matches through our secure messaging platform. Share photos, voice notes, and build meaningful conversations.',
  },
  {
    icon: Sparkles,
    title: 'AI Suggestions',
    description:
      'Get daily curated match recommendations based on your preferences, behavior patterns, and compatibility scores powered by machine learning.',
  },
  {
    icon: Users,
    title: 'Two Communities',
    description:
      'Dedicated platforms for Regular Matrimony and Farmer Matrimony, each tailored to the unique values, lifestyle, and expectations of its community.',
  },
];

export default function FeaturesSection() {
  return (
    <section id="features" className="py-24 lg:py-32 px-6 lg:px-10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 lg:mb-24">
          <h2 className="text-4xl lg:text-5xl font-['Playfair_Display'] tracking-tight mb-4">
            Designed for Your Journey
          </h2>
          <p className="text-[#8a8a8a] text-lg max-w-xl mx-auto">
            Every feature crafted to help you find your perfect life partner
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 lg:gap-12">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="group p-6 lg:p-8 border border-[#e6e6e2] hover:border-[#020202] transition-all duration-300"
              >
                <Icon className="w-8 h-8 mb-6 text-[#020202] group-hover:scale-110 transition-transform duration-300" />
                <h3 className="text-xl font-['Playfair_Display'] mb-3">
                  {feature.title}
                </h3>
                <p className="text-[#8a8a8a] text-sm leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
