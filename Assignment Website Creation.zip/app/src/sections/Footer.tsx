import { Link } from 'react-router';
import { Heart } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="py-16 px-6 lg:px-10 border-t border-[#e6e6e2]">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <Heart className="w-5 h-5" />
              <span className="font-['Playfair_Display'] text-xl">AVMatrimony</span>
            </Link>
            <p className="text-[#8a8a8a] text-sm leading-relaxed">
              One platform, two matrimony worlds. Finding your perfect match through AI-powered connections.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.1em] mb-4">Quick Links</h4>
            <ul className="space-y-2">
              <li><Link to="/" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">Home</Link></li>
              <li><Link to="/search" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">Search Matches</Link></li>
              <li><Link to="/subscription" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">Premium Plans</Link></li>
              <li><Link to="/register" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">Register</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.1em] mb-4">Categories</h4>
            <ul className="space-y-2">
              <li><Link to="/search?category=regular" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">Regular Matrimony</Link></li>
              <li><Link to="/search?category=farmer" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">Farmer Matrimony</Link></li>
              <li><Link to="/dashboard" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">My Dashboard</Link></li>
              <li><Link to="/matches" className="text-sm text-[#8a8a8a] hover:text-[#020202] transition-colors">My Matches</Link></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.1em] mb-4">Support</h4>
            <ul className="space-y-2">
              <li><span className="text-sm text-[#8a8a8a]">support@avmatrimony.com</span></li>
              <li><span className="text-sm text-[#8a8a8a]">+91 1800-123-4567</span></li>
              <li><span className="text-sm text-[#8a8a8a]">Mon - Sat, 9AM - 6PM</span></li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-[#e6e6e2] flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-[#8a8a8a]">
            &copy; {new Date().getFullYear()} AVMatrimony. All rights reserved.
          </p>
          <div className="flex gap-6">
            <span className="text-xs text-[#8a8a8a] hover:text-[#020202] cursor-pointer transition-colors">Privacy Policy</span>
            <span className="text-xs text-[#8a8a8a] hover:text-[#020202] cursor-pointer transition-colors">Terms of Service</span>
            <span className="text-xs text-[#8a8a8a] hover:text-[#020202] cursor-pointer transition-colors">Cookie Policy</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
