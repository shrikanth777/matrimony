import { useRef, useEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Link } from 'react-router';

gsap.registerPlugin(ScrollTrigger);

export default function HeroSection() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const imageRef = useRef<HTMLImageElement>(null);
  const textTopRef = useRef<HTMLDivElement>(null);
  const textBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const startPosTop = { x: '50vw', y: '-30vh', rotation: 15 };
    const startPosBottom = { x: '-50vw', y: '30vh', rotation: -15 };

    const tl = gsap.timeline({
      scrollTrigger: {
        trigger: sectionRef.current,
        start: 'top top',
        end: '+=150%',
        pin: true,
        scrub: 1.5,
        anticipatePin: 1,
      },
    });

    tl.set([textTopRef.current, textBottomRef.current], { opacity: 1 });

    tl.fromTo(
      textTopRef.current,
      startPosTop,
      { x: 0, y: 0, rotation: 5, ease: 'none' },
      0
    );

    tl.fromTo(
      textBottomRef.current,
      startPosBottom,
      { x: 0, y: 0, rotation: -5, ease: 'none' },
      0
    );

    tl.fromTo(
      imageRef.current,
      { scale: 1 },
      { scale: 1.5, ease: 'none' },
      0
    );

    return () => {
      tl.kill();
    };
  }, []);

  return (
    <div ref={sectionRef} className="hero-section" id="hero">
      <div className="hero-image-wrapper">
        <img
          ref={imageRef}
          src="/hero-couple.jpg"
          className="hero-image"
          alt="Couple"
        />
      </div>
      <div className="hero-text-container">
        <div className="hero-text text-top" ref={textTopRef} style={{ opacity: 0 }}>
          Where Hearts Meet
        </div>
        <div className="hero-text text-bottom" ref={textBottomRef} style={{ opacity: 0 }}>
          AI Perfect Matches
        </div>
      </div>
      <div className="hero-cta">
        <Link to="/register">
          <button className="btn-pill">Find Your Soulmate</button>
        </Link>
      </div>
    </div>
  );
}
