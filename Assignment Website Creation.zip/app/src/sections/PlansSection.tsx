import { trpc } from '@/providers/trpc';
import { Link } from 'react-router';
import { Check, Crown, Star, Diamond } from 'lucide-react';

const planIcons: Record<string, React.ElementType> = {
  free: Star,
  silver: Star,
  gold: Crown,
  platinum: Diamond,
};

export default function PlansSection() {
  const { data: plans } = trpc.subscription.getPlans.useQuery();

  const displayPlans = plans || [
    {
      id: 'free',
      name: 'Free',
      price: 0,
      duration: 'Lifetime',
      features: ['Create profile', 'Browse limited matches', 'Send 1 interest per day'],
    },
    {
      id: 'silver',
      name: 'Silver',
      price: 999,
      duration: '3 Months',
      features: ['All Free features', 'Browse unlimited matches', 'Send 10 interests per day', 'View contact details'],
    },
    {
      id: 'gold',
      name: 'Gold',
      price: 1999,
      duration: '6 Months',
      features: ['All Silver features', 'Unlimited interests', 'Priority profile listing', 'Chat with matches', 'AI match suggestions'],
    },
    {
      id: 'platinum',
      name: 'Platinum',
      price: 3499,
      duration: '12 Months',
      features: ['All Gold features', 'Personal matchmaker', 'Profile highlighting', 'Video call support', 'Premium badge'],
    },
  ];

  return (
    <section id="plans" className="py-24 lg:py-32 px-6 lg:px-10">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 lg:mb-24">
          <h2 className="text-4xl lg:text-5xl font-['Playfair_Display'] tracking-tight mb-4">
            Choose Your Plan
          </h2>
          <p className="text-[#8a8a8a] text-lg max-w-xl mx-auto">
            Flexible subscription plans to accelerate your journey to love
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {displayPlans.map((plan) => {
            const Icon = planIcons[plan.id] || Star;
            return (
              <div
                key={plan.id}
                className={`p-6 lg:p-8 border transition-all duration-300 hover:border-[#020202] ${
                  plan.id === 'gold'
                    ? 'border-[#020202] bg-[#020202] text-[#fcfbfa]'
                    : 'border-[#e6e6e2] bg-transparent'
                }`}
              >
                <Icon className={`w-6 h-6 mb-4 ${plan.id === 'gold' ? 'text-[#fcfbfa]' : 'text-[#020202]'}`} />
                <h3 className="text-xl font-['Playfair_Display'] mb-1">{plan.name}</h3>
                <div className="mb-4">
                  <span className="text-3xl font-['Playfair_Display']">
                    {plan.price === 0 ? 'Free' : `Rs. ${plan.price}`}
                  </span>
                  {plan.price > 0 && (
                    <span className={`text-xs ml-1 ${plan.id === 'gold' ? 'text-[#8a8a8a]' : 'text-[#8a8a8a]'}`}>
                      / {plan.duration}
                    </span>
                  )}
                </div>
                <ul className="space-y-3 mb-6">
                  {plan.features.map((feature, idx) => (
                    <li key={idx} className="flex items-start gap-2 text-sm">
                      <Check className={`w-4 h-4 mt-0.5 flex-shrink-0 ${plan.id === 'gold' ? 'text-[#fcfbfa]' : 'text-[#020202]'}`} />
                      <span className={plan.id === 'gold' ? 'text-[#e6e6e2]' : 'text-[#8a8a8a]'}>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link to="/subscription" className="block w-full">
                  <button
                    className={`w-full py-3 text-xs uppercase tracking-[0.1em] transition-all duration-300 ${
                      plan.id === 'gold'
                        ? 'bg-[#fcfbfa] text-[#020202] hover:bg-[#e6e6e2]'
                        : 'bg-[#020202] text-[#fcfbfa] hover:bg-[#333]'
                    }`}
                  >
                    {plan.price === 0 ? 'Get Started' : 'Subscribe'}
                  </button>
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
