import { trpc } from '@/providers/trpc';
import { Heart, Quote } from 'lucide-react';

export default function SuccessStoriesSection() {
  const { data: stories } = trpc.successStory.list.useQuery();

  const defaultStories = [
    {
      id: 1,
      coupleName: 'Priya & Rajesh',
      story: 'We met through AVMatrimony and instantly connected over our shared values. The AI matching was spot on! Within 6 months, we knew we were meant for each other.',
      category: 'regular' as const,
    },
    {
      id: 2,
      coupleName: 'Anita & Suresh',
      story: 'As farmers, we wanted someone who understood our lifestyle. The Farmer Matrimony section helped us find each other. Today we farm together and dream together.',
      category: 'farmer' as const,
    },
    {
      id: 3,
      coupleName: 'Meera & Vikram',
      story: 'The verification process gave our families confidence. We chatted for weeks before meeting, and when we finally did, it felt like we had known each other forever.',
      category: 'regular' as const,
    },
  ];

  const displayStories = stories && stories.length > 0 ? stories : defaultStories;

  return (
    <section className="py-24 lg:py-32 px-6 lg:px-10 bg-[#fcfbfa]">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16 lg:mb-24">
          <h2 className="text-4xl lg:text-5xl font-['Playfair_Display'] tracking-tight mb-4">
            Success Stories
          </h2>
          <p className="text-[#8a8a8a] text-lg max-w-xl mx-auto">
            Real couples who found their forever through AVMatrimony
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {displayStories.slice(0, 3).map((story) => (
            <div
              key={story.id}
              className="p-8 border border-[#e6e6e2] hover:border-[#020202] transition-all duration-300"
            >
              <Quote className="w-6 h-6 text-[#8a8a8a] mb-4" />
              <p className="text-[#020202] text-sm leading-relaxed mb-6 italic">
                {story.story}
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-[#020202] flex items-center justify-center">
                  <Heart className="w-4 h-4 text-[#fcfbfa]" />
                </div>
                <div>
                  <p className="text-sm font-medium">{story.coupleName}</p>
                  <p className="text-xs text-[#8a8a8a] uppercase tracking-wider">
                    {story.category === 'farmer' ? 'Farmer Matrimony' : 'Regular Matrimony'}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
